# camera_align: put the real camera exactly where the digital twin says

Part of Team J.I.T's entry to the Rockwell Automation + NVIDIA Innovation Lab hackathon (Fall 2026), Challenge 1: final vial inspection.

We choose camera poses in the CSI digital twin (Isaac Sim) and render the training data from those poses. This tool then helps a technician put the real webcam into the **same pose** on the line, so the model sees the same picture it was trained on. It also brings the camera back after a bump or a changeover without a vision engineer.

![aligned](examples/3_side_camera_aligned.png)

## How it works

1. **A shared reference.** A ChArUco board (5 × 7 squares of 30 mm) stands at the same spot in the twin and on the line. Every pose is measured relative to the board, so nobody measures the camera with a tape.
2. **Target from the twin.** `isaac_export_target.py` runs inside Isaac Sim. It reads the planned camera and saves its pose relative to the board (`target.json`) and a reference image (`target_ref.png`).
3. **Lens calibration.** `calibrate.py` learns the real webcam's lens from 15–25 board shots (`calib.json`). Our Logitech C922 came out at 0.239 px RMS.
4. **Live guidance.** `align_camera.py` finds the board in the live image, solves the camera pose (OpenCV solvePnP), compares it with the target, and shows the next move in plain words, for example `NEXT: PAN LEFT 2.1 deg`. A magenta outline shows where the board should be and a green one shows where it is now. The frame turns green (`ALIGNED`) when every axis is within tolerance (0.5 cm and 0.5° by default).
5. **Optional motors.** With two 28BYJ-48 steppers and an Arduino Nano, pan and tilt are turned automatically in a closed loop on the image. Position and roll stay manual.

Tested: on synthetic images (`selftest.py`) the app recovers a known offset to about 1 mm and 0.1°. The live app, calibration and motor firmware were run on real hardware.

## Quick start

```bash
pip install -r requirements.txt
python selftest.py                       # prints PASS, no camera needed
```

Turn off autofocus and auto zoom on the webcam first (Logitech G HUB on Windows, `v4l2-ctl` on Linux). The calibration is only valid for a fixed focus and zoom.

**1. Print the board.** Print `board_letter.pdf` or `board_a4.pdf` at 100 % (Actual size) and glue it to something flat. Check that 5 squares measure 150 mm. A two-colour 3D-printable board is in `board3d/`.

**2. Calibrate the camera** (once per camera and resolution):
```bash
python calibrate.py --cam 0 --width 1920 --height 1080
# SPACE = take a shot, C = compute and save calib.json
```

**3. Make a target in Isaac Sim** (skip this if you use our ready targets in `align_targets/`):
```bash
/isaac-sim/python.sh isaac_export_target.py add-board   --stage scene.usd --board-pos X Y Z
/isaac-sim/python.sh isaac_export_target.py apply-calib --stage scene.usd --camera /World/MyCam --calib calib.json
/isaac-sim/python.sh isaac_export_target.py export      --stage scene.usd --camera /World/MyCam \
      --width 1920 --height 1080 --out-dir align_target
```

**4. Align on the line.** Put the board at the same spot as in the twin, then:
```bash
python align_camera.py --cam 0 --calib calib.json \
       --target align_targets/diag/target.json --board align_targets/diag/board.json
```
Follow the `NEXT:` hint until the frame is green, lock the mount, and remove the board.

Useful options: `--motors [COM3]` motor mode (press `A`), `--motor-cal motors_diag.json` separate motor calibration per head, `--upside-down` for a camera hanging upside down, `--tol-cm 0.3 --tol-deg 0.3` tighter tolerance, `--image photo.jpg` check one photo. Keys: `O` overlay, `S` save current pose as the new target, `P` screenshot, `Q` quit.

## What is in this folder

| Path | What |
|---|---|
| `align_camera.py` | Live alignment app (manual or motor mode) |
| `calibrate.py` | Webcam lens calibration → `calib.json` |
| `isaac_export_target.py` | Isaac Sim side: add the board, copy the real lens into the sim camera, export the target |
| `motors.py` | Serial link to the Arduino, motor self-calibration, closed-loop pan/tilt |
| `firmware/pantilt/pantilt.ino` | Arduino Nano firmware for two steppers (AccelStepper, backlash take-up) |
| `board.json`, `board.py`, `make_board.py`, `board*.pdf`, `board.png` | ChArUco board definition and printable files |
| `board3d/` | 3D-printable two-colour board (`.scad` sources and `.stl`) |
| `selftest.py` | Synthetic end-to-end test, no hardware |
| `align_targets/` | Ready targets for the CSI line: `side/`, `diag/`, the poses they came from (`poses/`), the C922 calibration (`calib.json`) and where to put the board (`PLACEMENT.md`) |
| `examples/` | Screenshots of the app and the script that makes them |
| `mount/` | 3D-printable camera mounts, see below |
| `docs/` | Detailed guide, mount assembly on the real line, motor bench test, Russian version |

## 3D-printed mounts (`mount/stl/`)

All parts are oriented for printing (PETG, no supports). Sources are parametric: `mount/pantilt_mount.scad` for the pan-tilt head, the `mount/*.py` scripts for the rest. Build guide: [`mount/ASSEMBLY.md`](mount/ASSEMBLY.md).

**Motorized pan-tilt head** (C922, two 28BYJ-48, two 608 bearings):

| File | Part |
|---|---|
| `pan_base.stl` | Base cup with the pan motor and bearing, 84 mm flange with 4× M4 |
| `turntable.stl` | Turntable carrying the tilt uprights |
| `upright_motor.stl`, `upright_bearing.stl` | Tilt uprights (motor side, bearing side) |
| `cradle.stl` | Camera cradle, tilt axis through the camera |
| `roll_plate.stl` | Manual roll rocker, ±10° |
| `tilt_pin.stl` | Printed 8 mm tilt axle (if no steel rod) |
| `cam_screw.stl` | Printed 1/4"-20 camera screw (stopgap, metal is better) |
| `tray.stl`, `tray_v2.stl`, `tray_edges.stl` | Electronics tray for 2× ULN2003 + Arduino Nano (`tray_v2` is the latest) |
| `all_parts_plate.stl` | All head parts on one 250 mm build plate |

**Line mounts** (clamp to the line's aluminium portal, no drilling):

| File | Part |
|---|---|
| `side_arm.stl` | Side camera arm, collar on a portal post, centre 1/4"-20 hole for a ball head |
| `angle_plate.stl` | Plate that fixes the motorized pan-tilt head (diagonal camera) to a slotted steel angle (used at CSI) |
| `diag_riser.stl`, `diag_arm.stl` | Fully printed diagonal mount (earlier version, replaced by the steel angle) |
| `profile_plate.stl` | Adapter plate from the head to a 40 mm T-slot profile |
| `board_holder.stl` | Holds the 3D-printed board at the exact twin spot on the tray end |

**Fit tests:** `fit_test.stl`, `d_test.stl`, `uln_test_25x28.stl` (print these first to check bearing, shaft and peg fits).

`mount/thirdparty/nano_holder.stl` is a third-party Arduino Nano holder, credited to its original author.

## What happened on the real line

At the CSI visit on 2026-10-30 the diagonal camera was mounted upright on our motorized pan-tilt head, fixed to a slotted steel angle (`angle_plate.stl`) that is clamped to the portal beam with C-clamps, and aligned with this app in motor mode. The side camera could not be mounted rigidly at the required spot, so the final real setup is overhead + diagonal. Some distances on the real line differ from the twin (for example, frame post to tray 21 cm real vs ~31 cm in the model). Because the app measures the camera relative to the board on the tray, not relative to the frame, this difference does not affect the alignment.

## Lessons learned

* **Check the twin against the real line before designing mounts.** Our mounts were designed from the twin's geometry, and a 10 cm difference made the planned side pose unusable. Next time, before any CAD work, we would measure a few key distances on the real line (frame posts and beams to the tray, tray height, mounting surfaces) and compare them with the twin.
* **If they differ, fix the twin first.** Update the twin with the measured values, re-run the camera placement study and only then design the mounts and render the dataset.
* **Plan for adjustment.** Adjustable store parts (slotted steel angle, C-clamps) let us place the motorized head for the diagonal camera on site when the fixed printed holder did not fit.

## Credits

OpenCV (ArUco/ChArUco, solvePnP, calibration), NVIDIA Isaac Sim 5.1 and the CSI/UWM digital twin, AccelStepper (Arduino), OpenSCAD.
