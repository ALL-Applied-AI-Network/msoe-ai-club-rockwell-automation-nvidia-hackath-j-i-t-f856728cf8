"""Live camera alignment: tells you how to move the real camera until it matches the target pose
(exported from Isaac Sim by isaac_export_target.py, or saved earlier from a good real setup).

  python align_camera.py --cam 0 --calib calib.json --target target.json
  python align_camera.py --image test.jpg --calib calib.json --target target.json   (one still image)
  python align_camera.py --cam 0 --motors            (pan/tilt on motors, Arduino found automatically)
  python align_camera.py --cam 0 --motors COM3       (or name the port)

Two modes:
  manual (default)  every axis is a hint: move/turn the camera by hand until ALIGNED.
  --motors          position and roll are still hints for the hand, pan and tilt are turned by the
                    motors (firmware/pantilt/pantilt.ino). Press A to start; the first run nudges each
                    motor once to learn its direction and steps per degree (saved to motors.json).

Keys:  A = start/stop auto pan/tilt (--motors)  O = overlay mode (off / sim image blend / sim image edges)   + / - = overlay strength
       S = save the CURRENT pose as a new target (re-commissioning)  P = screenshot   Q = quit

Directions are given for a person standing BEHIND the camera, looking where it looks.
"""
import argparse
import collections
import json
import os
import time

import cv2
import numpy as np

from board import (board_pose_in_cam, board_size_m, cam_pose_in_board, detect, estimate_pose,
                   load_board, load_calibration, make_detector, open_camera, scale_K)

# Default "world up" in the board frame if the target file doesn't say (board frame: +Y down the board,
# +Z into the board). Vertical board, text upright -> up = -Y. Board lying face-up -> up = -Z.
UP_PRESETS = {"vertical": [0, -1, 0], "flat": [0, 0, -1]}


# ---------------------------------------------------------------- pose error maths
def _unit(v):
    return v / np.linalg.norm(v)


def _signed_angle(a, b, axis):
    """Angle to rotate a onto b about axis (right-hand rule), radians."""
    return np.arctan2(np.dot(np.cross(a, b), axis), np.dot(a, b))


def pose_errors(T_cur, T_tgt, up):
    """Corrections to apply to the current camera, all in the operator's terms.

    Returns dict: right_cm, up_cm, fwd_cm (move this much; negative = the opposite way),
    pan_deg (+ = pan left), tilt_deg (+ = tilt up), roll_deg (+ = clockwise seen from behind).
    """
    up = _unit(np.asarray(up, float))
    f_cur, f_tgt = T_cur[:3, 2], T_tgt[:3, 2]          # optical axes in the board frame
    near_vertical = abs(np.dot(f_cur, up)) > 0.95       # e.g. an overhead camera looking down
    # Horizontal heading of the CURRENT camera: the axes the operator thinks in.
    # Looking (almost) straight down/up, "forward" means toward the top of the image instead.
    h = (-T_cur[:3, 1]) if near_vertical else f_cur
    fh = _unit(h - np.dot(h, up) * up)
    right = np.cross(fh, up)                            # x = y_down x z  ->  right = fwd x up

    d = T_tgt[:3, 3] - T_cur[:3, 3]
    e = {"right_cm": 100 * np.dot(d, right), "up_cm": 100 * np.dot(d, up), "fwd_cm": 100 * np.dot(d, fh)}

    if near_vertical:
        # pan/tilt about world up is undefined here: use the camera's own axes instead
        # (tilt = about image x, pan = about image y, roll = about the optical axis).
        rv, _ = cv2.Rodrigues(T_cur[:3, :3].T @ T_tgt[:3, :3])
        rv = np.degrees(rv.ravel())
        e.update(tilt_deg=rv[0], pan_deg=-rv[1], roll_deg=rv[2])
        return e

    def horiz(f):
        return _unit(f - np.dot(f, up) * up)

    e["pan_deg"] = np.degrees(_signed_angle(horiz(f_cur), horiz(f_tgt), up))   # + about up = turn left
    e["tilt_deg"] = np.degrees(np.arcsin(np.clip(np.dot(f_tgt, up), -1, 1))
                               - np.arcsin(np.clip(np.dot(f_cur, up), -1, 1)))

    def roll(T):
        f, r = T[:3, 2], T[:3, 0]
        h = np.cross(f, up)                             # level "right" for this optical axis
        return _signed_angle(_unit(h), r, f)            # + = right side dipped = clockwise from behind

    e["roll_deg"] = (np.degrees(roll(T_tgt) - roll(T_cur)) + 180) % 360 - 180
    return e


WORDS = {
    "right_cm": ("MOVE RIGHT", "MOVE LEFT", "cm"),
    "up_cm": ("RAISE", "LOWER", "cm"),
    "fwd_cm": ("MOVE FORWARD", "MOVE BACK", "cm"),
    "pan_deg": ("PAN LEFT", "PAN RIGHT", "deg"),
    "tilt_deg": ("TILT UP", "TILT DOWN", "deg"),
    "roll_deg": ("ROLL CLOCKWISE", "ROLL COUNTER-CW", "deg"),
}
ORDER = ["right_cm", "up_cm", "fwd_cm", "pan_deg", "tilt_deg", "roll_deg"]


def instruction(key, val):
    pos, neg, unit = WORDS[key]
    return f"{pos if val > 0 else neg} {abs(val):.1f} {unit}"


def image_impact_px(e, fx, dist_m, half_diag_px):
    """How many pixels each error moves the picture: used to pick the most important step first."""
    imp = {}
    for k in ("right_cm", "up_cm"):
        imp[k] = fx * abs(e[k]) / 100 / max(dist_m, 1e-3)
    imp["fwd_cm"] = half_diag_px * abs(e["fwd_cm"]) / 100 / max(dist_m, 1e-3)  # scale change at the edge
    for k in ("pan_deg", "tilt_deg"):
        imp[k] = fx * np.radians(abs(e[k]))
    imp["roll_deg"] = half_diag_px * np.radians(abs(e["roll_deg"]))
    return imp


# ---------------------------------------------------------------- target / reference image
def load_target(path, board_orientation):
    with open(path) as f:
        t = json.load(f)
    T = np.array(t["T_board_cam"], float)
    up = t.get("up_in_board") or UP_PRESETS[board_orientation]
    ref = None
    if t.get("reference_image"):
        p = os.path.join(os.path.dirname(os.path.abspath(path)), t["reference_image"])
        ref = cv2.imread(p)
        if ref is None:
            print(f"warning: reference image {p} not found, overlay disabled")
    K_ref = np.array(t["intrinsics"]["K"], float) if t.get("intrinsics") else None
    return T, np.array(up, float), ref, K_ref


def warp_reference(ref, K_ref, K_live, size):
    """Re-render the sim image as if taken with the real lens (exact for a pure intrinsics change)."""
    if K_ref is None:
        return cv2.resize(ref, size)
    H = K_live @ np.linalg.inv(K_ref)
    return cv2.warpPerspective(ref, H, size)


# ---------------------------------------------------------------- drawing
def board_outline(cfg):
    w, h = board_size_m(cfg)
    return np.array([[0, 0, 0], [w, 0, 0], [w, h, 0], [0, h, 0]], np.float32)


def draw_poly(img, T_board_cam, K, cfg, color, thick):
    rvec, tvec = board_pose_in_cam(T_board_cam)
    if (np.linalg.inv(T_board_cam)[2, 3]) <= 0:      # board behind the camera
        return
    pts, _ = cv2.projectPoints(board_outline(cfg), rvec, tvec, K, None)
    pts = pts.reshape(-1, 2).astype(np.int32)
    cv2.polylines(img, [pts], True, color, thick, cv2.LINE_AA)
    cv2.circle(img, tuple(pts[0]), 6, color, -1, cv2.LINE_AA)   # top-left corner marker


def put(img, text, org, scale=0.7, color=(255, 255, 255), thick=2):
    # same thickness for the shadow: Hershey glyph spacing grows with thickness
    cv2.putText(img, text, (org[0] + 2, org[1] + 2), cv2.FONT_HERSHEY_SIMPLEX, scale, (0, 0, 0), thick, cv2.LINE_AA)
    cv2.putText(img, text, org, cv2.FONT_HERSHEY_SIMPLEX, scale, color, thick, cv2.LINE_AA)


def shade(img, x0, y0, x1, y1, a=0.55):
    roi = img[max(0, y0):y1, max(0, x0):x1]
    roi[:] = (roi * (1 - a)).astype(np.uint8)


MOTOR_KEYS = ("pan_deg", "tilt_deg")


def draw_panel(img, e, imp, tol_cm, tol_deg, status, motor_msg=None):
    h, w = img.shape[:2]
    shade(img, 0, h - 38, w, h)
    if e is None:
        shade(img, 0, 0, w, 75)
        put(img, status, (20, 50), 1.0, (0, 0, 255), 2)
        return
    ok = {k: abs(e[k]) <= (tol_cm if k.endswith("cm") else tol_deg) for k in ORDER}
    by_hand = [k for k in ORDER if not (motor_msg and k in MOTOR_KEYS)]
    shade(img, 0, 0, 520, 95 + 28 * len(ORDER) - 10 + (28 if motor_msg else 0))
    if all(ok.values()):
        cv2.rectangle(img, (0, 0), (w - 1, h - 1), (0, 200, 0), 12)
        put(img, "ALIGNED - lock the mount", (20, 55), 1.3, (0, 255, 0), 3)
    elif any(not ok[k] for k in by_hand):
        nxt = max((k for k in by_hand if not ok[k]), key=lambda k: imp[k])
        put(img, "NEXT: " + instruction(nxt, e[nxt]), (20, 55), 1.3, (0, 255, 255), 3)
    else:
        put(img, "NEXT: motors (pan/tilt)", (20, 55), 1.3, (0, 255, 255), 3)
    y = 95
    for k in ORDER:
        tol = tol_cm if k.endswith("cm") else tol_deg
        col = (0, 220, 0) if ok[k] else (0, 165, 255)
        tag = "M " if k not in by_hand else ""
        label = f"{'OK ' if ok[k] else '   '}{tag}{instruction(k, e[k])}"
        put(img, label, (20, y), 0.65, col, 2)
        # gauge: centre = perfect, full bar = 10x tolerance
        x0, bw = 330, 160
        cv2.rectangle(img, (x0, y - 13), (x0 + bw, y - 3), (80, 80, 80), -1)
        frac = float(np.clip(e[k] / (10 * tol), -1, 1))
        cx = x0 + bw // 2
        cv2.rectangle(img, (cx, y - 13), (int(cx + frac * bw / 2), y - 3), col, -1)
        cv2.line(img, (cx, y - 16), (cx, y), (255, 255, 255), 1)
        y += 28
    if motor_msg:
        put(img, motor_msg, (20, y), 0.6, (255, 200, 0), 2)
    put(img, status, (20, h - 15), 0.55, (200, 200, 200), 1)


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cam", default="0", help="index (0) or path (/dev/video2)")
    ap.add_argument("--image", help="process one still image instead of the live camera")
    ap.add_argument("--calib", default="calib.json")
    ap.add_argument("--target", default="target.json")
    ap.add_argument("--board", default=None, help="board.json (default: next to this script)")
    ap.add_argument("--board-orientation", choices=list(UP_PRESETS), default="vertical",
                    help="only used if the target has no up_in_board (targets saved from a real camera)")
    ap.add_argument("--tol-cm", type=float, default=0.5)
    ap.add_argument("--tol-deg", type=float, default=0.5)
    ap.add_argument("--smooth", type=int, default=10, help="median over N frames")
    ap.add_argument("--out", default="align_result.png", help="--image mode: annotated output")
    ap.add_argument("--motors", nargs="?", const="auto", default=None,
                    help="motorised pan/tilt: serial port of the Arduino, or nothing to find it")
    ap.add_argument("--motor-cal", default="motors.json", help="where the learned steps/degree are kept")
    ap.add_argument("--recal-motors", action="store_true", help="learn motor directions again")
    ap.add_argument("--upside-down", action="store_true",
                    help="camera hangs upside down (e.g. DIAG under its arm): turn every frame 180 deg so it matches "
                         "the upright sim camera; calib.json from the upright camera is converted automatically")
    a = ap.parse_args()

    board, cfg = load_board(a.board)
    det = make_detector(board)
    K0, dist0, calib_size = load_calibration(a.calib)
    if os.path.exists(a.target):
        T_tgt, up, ref, K_ref = load_target(a.target, a.board_orientation)
    else:   # no target yet: aim the camera by hand and press S to make the current pose the target
        print(f"no target file {a.target}: press S to use the current pose as the target")
        T_tgt, up, ref, K_ref = None, np.array(UP_PRESETS[a.board_orientation], float), None, None

    if a.image:
        frames = iter([cv2.imread(a.image)])
        cap = None
    else:
        cap = open_camera(a.cam, calib_size[0], calib_size[1])

    hist = collections.deque(maxlen=max(1, a.smooth))
    overlay_mode, alpha = (1 if ref is not None else 0), 0.4
    K = dist = ref_live = ref_edges = None
    last_T, last_print = None, 0.0

    motors = None
    if a.motors and not a.image:
        from motors import AutoPanTilt, SerialPanTilt
        link = SerialPanTilt(None if a.motors == "auto" else a.motors)
        print(f"motors on {link.port}")
        motors = AutoPanTilt(link, tol_deg=a.tol_deg, cal_path=a.motor_cal, recalibrate=a.recal_motors)

    while True:
        if cap is None:
            frame = next(frames, None)
        else:
            ok, frame = cap.read()
            frame = frame if ok else None
        if frame is not None and a.upside_down:
            frame = cv2.rotate(frame, cv2.ROTATE_180)
        if frame is None:
            if cap is not None:
                print("camera read failed")
            break
        size = (frame.shape[1], frame.shape[0])
        if K is None:   # first frame: fix intrinsics for this resolution
            if size != calib_size:
                print(f"note: image {size} != calibration {calib_size}, rescaling K")
            K = scale_K(K0, calib_size, size)
            dist = dist0
            if a.upside_down:
                # 180 deg turn about the image centre: principal point mirrored, tangential terms change sign
                K = K.copy(); K[0, 2] = size[0] - 1 - K[0, 2]; K[1, 2] = size[1] - 1 - K[1, 2]
                dist = np.array(dist0, float).ravel().copy()
                dist[2:4] *= -1
            if ref is not None:
                ref_live = warp_reference(ref, K_ref, K, size)
                g = cv2.Canny(cv2.cvtColor(ref_live, cv2.COLOR_BGR2GRAY), 60, 160)
                ref_edges = np.zeros_like(ref_live); ref_edges[g > 0] = (255, 0, 255)

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        ch_c, ch_i, _, _ = detect(det, gray)
        res = estimate_pose(board, ch_c, ch_i, K, dist)
        n = 0 if ch_i is None else len(ch_i)

        # display undistorted so the sim overlay / ghost (pinhole, no distortion) line up
        vis = cv2.undistort(frame, K, dist)
        if overlay_mode == 1 and ref_live is not None:
            vis = cv2.addWeighted(vis, 1 - alpha, ref_live, alpha, 0)
        elif overlay_mode == 2 and ref_edges is not None:
            m = ref_edges.any(axis=2)
            vis[m] = (vis[m] * (1 - min(1, alpha * 2)) + ref_edges[m] * min(1, alpha * 2)).astype(np.uint8)

        if T_tgt is not None:
            draw_poly(vis, T_tgt, K, cfg, (255, 0, 255), 2)      # where the board SHOULD be (magenta)
        e = imp = None
        e_frame = None
        if res is None:
            hist.clear()
            status = f"BOARD NOT FOUND ({n} corners) - make the whole board visible, check lighting"
        else:
            rvec, tvec, rerr = res
            T_cur = cam_pose_in_board(rvec, tvec)
            last_T = T_cur
            draw_poly(vis, T_cur, K, cfg, (0, 255, 0), 2)         # where it IS (green)
        if res is not None and T_tgt is None:
            status = "NO TARGET - aim the camera where it should be, press S to save this pose as the target"
        elif res is not None:
            e_frame = pose_errors(T_cur, T_tgt, up)
            hist.append(e_frame)
            e = {k: float(np.median([h[k] for h in hist])) for k in ORDER}
            dist_m = float(np.linalg.norm(np.linalg.inv(T_cur)[:3, 3]))
            imp = image_impact_px(e, K[0, 0], dist_m, 0.5 * np.hypot(*size))
            status = (f"corners {n}  reproj {rerr:.2f}px  board at {dist_m*100:.0f} cm  "
                      f"tol {a.tol_cm}cm/{a.tol_deg}deg  magenta=target green=now")
            if time.time() - last_print > 1.0 or cap is None:
                print("  ".join(instruction(k, e[k]) for k in ORDER))
                last_print = time.time()
        if motors is not None:
            motors.update(e_frame)
        draw_panel(vis, e, imp, a.tol_cm, a.tol_deg, status, motors.msg if motors else None)

        if cap is None:
            cv2.imwrite(a.out, vis)
            print(f"wrote {a.out}")
            if e is not None:
                print(json.dumps({k: round(v, 3) for k, v in e.items()}))
            break

        cv2.imshow("align camera", vis)
        k = cv2.waitKey(1) & 0xFF
        if k == ord("q"):
            break
        elif k == ord("a") and motors is not None:
            motors.stop() if motors.active else motors.start()
        elif k == ord("o"):
            overlay_mode = (overlay_mode + 1) % 3
        elif k in (ord("+"), ord("=")):
            alpha = min(0.9, alpha + 0.1)
        elif k == ord("-"):
            alpha = max(0.1, alpha - 0.1)
        elif k == ord("p"):
            fn = time.strftime("align_%Y%m%d_%H%M%S.png"); cv2.imwrite(fn, vis); print("saved", fn)
        elif k == ord("s") and last_T is not None:
            stamp = time.strftime("%Y%m%d_%H%M%S")
            img_fn = f"target_real_{stamp}.png"
            cv2.imwrite(img_fn, cv2.undistort(frame, K, dist))
            out = {"source": "real_camera", "T_board_cam": last_T.tolist(), "up_in_board": up.tolist(),
                   "intrinsics": {"K": K.tolist(), "image_size": list(size)}, "reference_image": img_fn}
            with open(f"target_real_{stamp}.json", "w") as f:
                json.dump(out, f, indent=2)
            print(f"saved target_real_{stamp}.json (+ {img_fn}), it is the target now")
            T_tgt = last_T.copy()                                   # use it right away
            hist.clear()
            ref_live = cv2.undistort(frame, K, dist)
            g = cv2.Canny(cv2.cvtColor(ref_live, cv2.COLOR_BGR2GRAY), 60, 160)
            ref_edges = np.zeros_like(ref_live); ref_edges[g > 0] = (255, 0, 255)

    if motors is not None:
        motors.link.close()
    if cap is not None:
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
