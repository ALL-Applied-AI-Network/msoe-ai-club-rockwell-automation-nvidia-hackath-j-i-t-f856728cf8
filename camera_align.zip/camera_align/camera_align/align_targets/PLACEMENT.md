# camera_align targets: SIDE and DIAG (CSI visit)

Targets: `side/` (SIDE skyline camera) and `diag/` (DIAG corner camera), each with `target.json`, `board.json`, and
`target_ref.png`. They were exported from the mountable v2 poses (`side_mount_v2_pose.json`, `diag_mount_v2_pose.json`)
with the real Logitech C922 calibration (`calib.json`: fx 1441.7 px, 1920x1080). The live app needs calibration of the
same camera, at the same resolution, focus and zoom.

## Where the ChArUco board stands (the same placement for both targets)

Board: 5 x 7 squares of 30 mm (150 x 210 mm), DICT_5X5_100. Print at 100 %; check that 5 squares measure 150 mm.

* **Edge:** the +x end of the good tray (the short end with vials G26-G30). This is the **left edge of the overhead
  CapSealCam image**, the end next to the MagneMover lane ends and the 50x50 aluminium portal.
* **Distance:** the printed pattern plane stands upright, parallel to that end face of the tray top plate, **7.0 mm in
  front of it** (holder spacing).
* **Faces:** away from the tray, toward +x, i.e. toward the SIDE camera and the portal. Text and markers are upright
  (marker 0 at the top left when you face the print).
* **Sideways:** centred on the tray width. The left and right board edges are each 81.5 mm in from the long edges of
  the tray top plate. Facing the print, the left edge is on the G26 side and the right edge on the G30 side.
* **Height:** board centre at cap-top height (66 mm above the tray top surface). The **bottom edge is 39 mm below the
  tray top surface** and the top edge 171 mm above it.
  Tray top plate: 6.35 mm thick; top surface at world z 1.225 m.

World coordinates (CSI line twin, metres, Z up): board centre (-0.2044, -0.6576, 1.291); USD rotateXYZ (90, 0, 90).

## Use

1. Place the board as above and light its printed face (in the twin it gets little light from the overhead lamp).
2. SIDE: `python align_camera.py --calib calib.json --target side/target.json --board side/board.json` (run in the
   unzipped `align_targets` folder, with camera_align's scripts on the path or copied next to it). The camera is 0.33 m straight in front of the board
   (sees it face-on, all 24 corners in the reference).
3. DIAG: `python align_camera.py --calib calib.json --target diag/target.json --board diag/board.json`. The board is seen about 58 deg off its normal from the
   corner camera, so expect fewer corners (17 of 24 in the reference). Good light helps.
4. Remove the board afterwards: it blocks the side camera's view of the caps.

Mounting (from mount_survey): SIDE on a 4040 arm from the -y face of portal post P1, lens (0.127, -0.713, 1.291);
DIAG hanging under a 4040 arm on a riser standing on the portal top beam, lens (-0.026, -0.249, 1.674).
