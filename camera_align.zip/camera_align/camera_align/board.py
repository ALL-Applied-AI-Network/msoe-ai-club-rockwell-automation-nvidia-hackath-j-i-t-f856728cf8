"""Shared ChArUco board definition and pose helpers.

Board frame (OpenCV convention, used everywhere in these tools):
  origin = top-left corner of the printed board (as seen from the front, text-up),
  +X = to the right along the board, +Y = down along the board, +Z = into the board.
Camera frame (OpenCV): +X right in the image, +Y down in the image, +Z forward (optical axis).
All lengths in metres.
"""
import json
import os

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))


def load_board(path=None):
    path = path or os.path.join(HERE, "board.json")
    with open(path) as f:
        cfg = json.load(f)
    d = cv2.aruco.getPredefinedDictionary(getattr(cv2.aruco, cfg["dictionary"]))
    board = cv2.aruco.CharucoBoard(
        (cfg["squares_x"], cfg["squares_y"]), cfg["square_length_m"], cfg["marker_length_m"], d
    )
    return board, cfg


def board_size_m(cfg):
    return cfg["squares_x"] * cfg["square_length_m"], cfg["squares_y"] * cfg["square_length_m"]


def make_detector(board):
    params = cv2.aruco.CharucoParameters()
    det_params = cv2.aruco.DetectorParameters()
    det_params.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
    return cv2.aruco.CharucoDetector(board, params, det_params)


def detect(detector, gray):
    """Return (charuco_corners, charuco_ids, marker_corners, marker_ids)."""
    return detector.detectBoard(gray)


def estimate_pose(board, ch_corners, ch_ids, K, dist, min_corners=6):
    """Pose of the board in the camera: (rvec, tvec, reproj_err_px) or None."""
    if ch_ids is None or len(ch_ids) < min_corners:
        return None
    obj, img = board.matchImagePoints(ch_corners, ch_ids)
    if obj is None or len(obj) < min_corners:
        return None
    ok, rvec, tvec = cv2.solvePnP(obj, img, K, dist, flags=cv2.SOLVEPNP_ITERATIVE)
    if not ok:
        return None
    rvec, tvec = cv2.solvePnPRefineLM(obj, img, K, dist, rvec, tvec)
    proj, _ = cv2.projectPoints(obj, rvec, tvec, K, dist)
    err = float(np.sqrt(np.mean(np.sum((proj.reshape(-1, 2) - img.reshape(-1, 2)) ** 2, axis=1))))
    return rvec, tvec, err


def cam_pose_in_board(rvec, tvec):
    """solvePnP gives board->camera. Return 4x4 T_board_cam (camera pose in the board frame)."""
    R, _ = cv2.Rodrigues(rvec)
    T = np.eye(4)
    T[:3, :3] = R.T
    T[:3, 3] = (-R.T @ np.asarray(tvec).reshape(3))
    return T


def board_pose_in_cam(T_board_cam):
    """Inverse of cam_pose_in_board: (rvec, tvec) for cv2.projectPoints."""
    T = np.linalg.inv(T_board_cam)
    rvec, _ = cv2.Rodrigues(T[:3, :3])
    return rvec, T[:3, 3].reshape(3, 1)


def load_calibration(path):
    with open(path) as f:
        c = json.load(f)
    return np.array(c["K"], float), np.array(c["dist"], float), tuple(c["image_size"])


def scale_K(K, from_size, to_size):
    """Rescale intrinsics when the image resolution differs (same aspect ratio assumed)."""
    sx, sy = to_size[0] / from_size[0], to_size[1] / from_size[1]
    K = K.copy()
    K[0, 0] *= sx; K[0, 2] *= sx
    K[1, 1] *= sy; K[1, 2] *= sy
    return K


def open_camera(cam, width, height):
    """Open a webcam by index ("0") or path. V4L2 on Linux, DirectShow on Windows, default elsewhere."""
    import sys
    src = int(cam) if str(cam).isdigit() else cam
    backend = {"linux": cv2.CAP_V4L2, "win32": cv2.CAP_DSHOW}.get(sys.platform, cv2.CAP_ANY)
    cap = cv2.VideoCapture(src, backend)
    if not cap.isOpened():
        cap = cv2.VideoCapture(src)
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    # autofocus moves the lens and silently invalidates calib.json: lock it (C922 obeys this on V4L2 and DirectShow)
    cap.set(cv2.CAP_PROP_AUTOFOCUS, 0)
    focus = os.environ.get("CAM_FOCUS")      # e.g. CAM_FOCUS=30; same value for calibration and alignment
    if focus is not None:
        cap.set(cv2.CAP_PROP_FOCUS, float(focus))
    return cap
