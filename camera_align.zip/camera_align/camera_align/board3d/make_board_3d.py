"""ChArUco board as a 2-colour 3D print (white plate + black inlay), from board.json.

    python make_board_3d.py            -> board_white.scad / board_black.scad (+ STL if openscad is installed)

Printed face DOWN on the bed (flat, matte with a textured sheet). Black pattern is 0.6 mm deep.
"""
import json
import os
import subprocess
import sys

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from board import load_board  # noqa: E402

MARGIN = 10.0      # white quiet zone around the pattern, mm
THICK = 4.0        # plate thickness, mm
INLAY = 0.6        # black layer depth, mm


def black_rects(board, cfg):
    sq_mm = cfg["square_length_m"] * 1000
    mk_mm = cfg["marker_length_m"] * 1000
    bits = board.getDictionary().markerSize + 2
    # pixels per mm chosen so squares, marker borders and marker bits all land on whole pixels
    for ppm in range(1, 200):
        if all(abs(v * ppm - round(v * ppm)) < 1e-6 for v in (sq_mm, mk_mm, mk_mm / bits, (sq_mm - mk_mm) / 2)):
            break
    w, h = int(round(cfg["squares_x"] * sq_mm * ppm)), int(round(cfg["squares_y"] * sq_mm * ppm))
    img = board.generateImage((w, h), marginSize=0, borderBits=1)
    black = img < 128
    # row runs, merged downwards into rectangles
    rects, open_runs = [], {}
    for y in range(h + 1):
        runs = set()
        if y < h:
            row = np.concatenate([[False], black[y], [False]])
            d = np.diff(row.astype(int))
            runs = set(zip(np.where(d == 1)[0], np.where(d == -1)[0]))
        for r in list(open_runs):
            if r not in runs:
                y0 = open_runs.pop(r)
                rects.append((r[0] / ppm, y0 / ppm, (r[1] - r[0]) / ppm, (y - y0) / ppm))
        for r in runs:
            open_runs.setdefault(r, y)
    return rects, w / ppm, h / ppm


def main():
    board, cfg = load_board()
    rects, bw, bh = black_rects(board, cfg)
    # board frame: x right, y DOWN (as seen from the front). Model: face at z=0 on the bed, looking from below
    # shows the face, so mirror y->x keeps it readable from the front after printing face down.
    e = 0.01   # inset so black squares touching at a corner stay separate solids (manifold mesh)
    cubes = "\n".join(
        f"translate([{-(x + w) + e:.4f}, {-(y + h) + e:.4f}, 0]) cube([{w - 2 * e:.4f}, {h - 2 * e:.4f}, {INLAY}]);"
        for x, y, w, h in rects)
    # x is negated: seen from below (the printed face), the pattern reads normally
    black = f"// {len(rects)} rectangles, board {bw} x {bh} mm\nunion() {{\n{cubes}\n}}\n"
    white = (f"difference() {{\n translate([{-bw - MARGIN}, {-bh - MARGIN}, 0]) "
             f"cube([{bw + 2 * MARGIN}, {bh + 2 * MARGIN}, {THICK}]);\n"
             f" translate([0, 0, -0.01]) scale([1, 1, 1.05]) {{\n{cubes}\n }}\n}}\n")
    open(os.path.join(HERE, "board_black.scad"), "w").write(black)
    open(os.path.join(HERE, "board_white.scad"), "w").write(white)
    try:
        for n in ("board_black", "board_white"):
            subprocess.run(["openscad", "-q", "-o", n + ".stl", n + ".scad"], cwd=HERE, check=True)
        print("wrote board_black.stl, board_white.stl")
    except (OSError, subprocess.CalledProcessError) as e:
        print("openscad not available, only .scad written:", e)
    print(f"pattern {bw:.1f} x {bh:.1f} mm, plate {bw + 2 * MARGIN:.1f} x {bh + 2 * MARGIN:.1f} x {THICK} mm")


if __name__ == "__main__":
    main()
