"""One-time intrinsic calibration of the real camera with the printed ChArUco board.

  python calibrate.py --cam 0 --width 1280 --height 720
Hold the board (or move the camera) at ~15-25 different distances / angles / image corners.
  SPACE = grab a view (only accepted if enough corners are seen)   C = calibrate & save   Q = quit
Writes calib.json (K, dist, image_size). Repeat if you change resolution, zoom or focus.
Turn OFF autofocus if the webcam allows it (v4l2-ctl -c focus_automatic_continuous=0), otherwise K drifts.
"""
import argparse
import json

import cv2
import numpy as np

from board import detect, load_board, make_detector, open_camera

ap = argparse.ArgumentParser()
ap.add_argument("--cam", default="0", help="index (0) or path (/dev/video2)")
ap.add_argument("--width", type=int, default=1280)
ap.add_argument("--height", type=int, default=720)
ap.add_argument("--out", default="calib.json")
ap.add_argument("--board", default=None)
ap.add_argument("--images", nargs="*", help="calibrate from saved images instead of a live camera")
a = ap.parse_args()

board, cfg = load_board(a.board)
det = make_detector(board)
all_obj, all_img, size = [], [], None


def add_view(gray):
    ch_c, ch_i, _, _ = detect(det, gray)
    if ch_i is None or len(ch_i) < 8:
        return 0
    obj, img = board.matchImagePoints(ch_c, ch_i)
    all_obj.append(obj); all_img.append(img)
    return len(ch_i)


def calibrate():
    flags = 0
    rms, K, dist, _, _ = cv2.calibrateCamera(all_obj, all_img, size, None, None, flags=flags)
    out = {"K": K.tolist(), "dist": dist.ravel().tolist(), "image_size": list(size),
           "rms_px": rms, "views": len(all_obj),
           "hfov_deg": float(np.degrees(2 * np.arctan(size[0] / (2 * K[0, 0])))),
           "vfov_deg": float(np.degrees(2 * np.arctan(size[1] / (2 * K[1, 1]))))}
    with open(a.out, "w") as f:
        json.dump(out, f, indent=2)
    print(f"saved {a.out}: RMS {rms:.3f} px from {len(all_obj)} views, HFOV {out['hfov_deg']:.1f} deg")
    print("RMS under ~0.5 px is good; above 1 px: more varied views, flatter board, fixed focus.")


if a.images:
    for p in a.images:
        g = cv2.imread(p, cv2.IMREAD_GRAYSCALE)
        size = (g.shape[1], g.shape[0])
        print(p, add_view(g), "corners")
    calibrate()
    raise SystemExit

cap = open_camera(a.cam, a.width, a.height)
while True:
    ok, frame = cap.read()
    if not ok:
        print("camera read failed"); break
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    size = (gray.shape[1], gray.shape[0])
    ch_c, ch_i, m_c, m_i = detect(det, gray)
    vis = frame.copy()
    if m_i is not None:
        cv2.aruco.drawDetectedMarkers(vis, m_c, m_i)
    if ch_i is not None:
        cv2.aruco.drawDetectedCornersCharuco(vis, ch_c, ch_i, (0, 255, 0))
    n = 0 if ch_i is None else len(ch_i)
    cv2.putText(vis, f"views: {len(all_obj)}  corners now: {n}  [SPACE grab, C calibrate, Q quit]",
                (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
    cv2.imshow("calibrate", vis)
    k = cv2.waitKey(1) & 0xFF
    if k == ord(" "):
        got = add_view(gray)
        print(f"view {len(all_obj)}: {got} corners" if got else "rejected: need >= 8 corners")
    elif k == ord("c") and len(all_obj) >= 8:
        calibrate()
    elif k == ord("q"):
        break
cap.release(); cv2.destroyAllWindows()
