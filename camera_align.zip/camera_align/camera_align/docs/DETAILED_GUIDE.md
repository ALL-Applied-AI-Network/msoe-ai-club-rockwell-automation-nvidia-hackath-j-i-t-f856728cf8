# Camera placement from the digital twin (camera_align)

Built 2026-10-22 for Team J.I.T (Challenge 1). The idea: first place the camera perfectly in Isaac Sim, then the app running on the real camera says "up / down / left / right / forward / back / pan / tilt / roll" until the camera sits exactly where it was in the simulator.

## How it works (in short)

1. **Shared reference.** A printed ChArUco board (chessboard with markers, 15×21 cm) is placed at the same spot in the twin and on the real line, for example standing upright against the end of the tray/fixture. Everything is measured **relative to the board**, so you never have to measure the camera position with a tape.
2. **Simulator.** `isaac_export_target.py` takes the ideal camera from the scene and saves where it is relative to the board (`target.json`) plus a reference frame (`target_ref.png`).
3. **Calibration (once).** `calibrate.py` learns the webcam lens (focal length, centre, distortion) from 15–25 shots of the board.
4. **Live app.** `align_camera.py` finds the board in the image, solves solvePnP (where the camera is now), compares it with the target and shows the next step in big letters: `NEXT: PAN LEFT 2.1 deg`. Below are bars for all 6 axes. When everything is within tolerance (0.5 cm and 0.5° by default) the frame turns green: `ALIGNED`.
   - Magenta outline: where the board **should** be in the image. Green: where it is **now**. When they match, the camera is placed correctly.
   - A semi-transparent frame from the simulator over the video (key `O`: overlay / outlines only / off).
   - Directions are given for a person standing **behind the camera** and looking the same way it looks.
   - The step is chosen by which error moves the image the most, so big corrections come first, then small ones.

Tested without hardware (`selftest.py`): the camera was moved synthetically by "right 2 cm, up 1 cm, back 3 cm, pan 3°, tilt 2°, roll 1.5°" and the app returned the same numbers to ~1 mm and ~0.1°. Calibration on synthetic data recovered a focal length of 899 out of 900. The Isaac part was checked on a USD scene (without rendering): axes and signs match. **The reference frame has not been rendered in real Isaac Sim yet**; that is the first step on Brev.

## Files

| File | What it does | Where to run |
|---|---|---|
| `board.json` | Board dimensions. The same file is used in every step | everywhere |
| `board_letter.pdf` / `board_a4.pdf` | Board to print on paper (centred, with a 100 mm check ruler) | printer |
| `board.pdf` / `board.png` | Board at exact size without margins (also the texture for Isaac Sim) | Isaac Sim |
| `board3d/` | 2-colour 3D-printable board (`board_white.stl` + `board_black.stl`) | 3D printer |
| `make_board.py` | Regenerate the board if `board.json` changed | any PC |
| `calibrate.py` | Lens calibration → `calib.json` | PC with the camera |
| `isaac_export_target.py` | Board into the scene, camera FOV from calibration, target export | Isaac Sim (Brev) |
| `align_camera.py` | Live hints | PC with the camera |
| `selftest.py` | Check without a camera | any PC |
| `motors.py` | Motor mode: link to the Arduino, self-calibration, pan/tilt control | PC with the camera |
| `firmware/pantilt/pantilt.ino` | Arduino Nano firmware for the two steppers | Arduino IDE |
| `selftest_motors.py` (not included in this package) | Motor mode check in simulation, no hardware | any PC |
| `mount/` | 3D-printable pan-tilt mount + build guide (`ASSEMBLY.md`) | 3D printer |

## Step by step

### 0. Install
Windows (in the `camera_align` folder, e.g. VS Code terminal):
```
py -m pip install -r requirements.txt
py selftest.py                          # must print PASS
```
On Windows, turn off autofocus (and auto zoom) of the C922 in Logitech G HUB, keep zoom at 100 %.

Linux PC at the line:
```bash
pip install -r requirements.txt
v4l2-ctl --list-devices                 # which /dev/videoN is our webcam
v4l2-ctl -d /dev/video0 -c focus_automatic_continuous=0 -c focus_absolute=0   # turn off autofocus if present
python selftest.py                      # must print PASS
```
Autofocus and auto zoom must be off: if the focus drifts, the calibration is no longer valid.

### 1. Print the board
Paper: print `board_letter.pdf` (or `board_a4.pdf`) at **100% / Actual size** (not "Fit to page"). Glue it onto something flat and stiff (foam board, clipboard). Check with a ruler: the check line must be 100 mm and 5 squares 150 mm. If a square is not exactly 30.0 mm, put the real value into `square_length_m` in `board.json` and multiply `marker_length_m` by the same ratio. Matte paper is better than glossy (fewer reflections).

3D print: load `board3d/board_white.stl` and `board3d/board_black.stl` together as one object with two parts, white and black filament, face down on a textured plate, matte PLA.

### 2. Calibrate the camera (once per camera and resolution)
```bash
python calibrate.py --cam 0 --width 1280 --height 720          # Windows: py calibrate.py --cam 0
```
Move the board around the frame: close, far, in the corners, tilted up to ~45°. `SPACE` = take a shot, after 15–25 shots `C` = compute and save `calib.json`. RMS < 0.5 px is good. The script also prints the camera's HFOV. The lens calibration does not depend on which board you used (paper or 3D), only on the camera, its focus and zoom.

### 3. Isaac Sim: board into the scene and target
(on Brev, `jit_scene.usd` from the CSI twin scene; copy the whole `camera_align` folder there)

```bash
cd camera_align
# a) board: position of the board centre in metres (world coordinates), rotation XYZ in degrees.
#    Default 90 0 -90 = standing upright, facing -X (Z-up scene).
/isaac-sim/python.sh isaac_export_target.py add-board --stage ../jit_scene.usd --board-pos 0.62 0.10 0.80
# b) give the sim camera the same field of view as the real one (from calib.json)
/isaac-sim/python.sh isaac_export_target.py apply-calib --stage ../jit_scene.usd --camera /World/SideCam --calib calib.json
# c) place the camera perfectly in the GUI (look through it), save the scene, then:
/isaac-sim/python.sh isaac_export_target.py export --stage ../jit_scene.usd --camera /World/SideCam \
      --width 1280 --height 720 --out-dir align_target
```
This gives an `align_target/` folder with `target.json`, `target_ref.png` and a copy of `board.json`. Copy it to the PC at the line (`brev copy`).

How to place the board in the scene: the easiest is to add it roughly with command a), then select `/World/AlignBoard` in the GUI and move the gizmo so it stands exactly where it will physically stand on the line (for example, right against the end of the fixture, bottom edge on the table). On the board, +Z = front face, +Y = top of the text. The front face must look at the camera. If the board looks mirrored in the camera view or is missing, it is facing backwards.

For the overhead camera: lay the board flat on the tray, face up (`--board-rot 0 0 0`); the app handles this on its own.

The numbers (0.62 0.10 0.80) in the example are made up; use the real coordinates from your scene.

### 4. On the line
1. Put the board at the **same** spot as in the twin. All the accuracy depends on this: an error in the board position = the same error in the camera. Best to locate it against a stop or edge, not with a tape measure.
2. Run:
   ```bash
   python align_camera.py --cam 0 --calib calib.json --target align_target/target.json --board align_target/board.json
   ```
3. Move the mount following the `NEXT:` hint. The usual order: first position (up/down, forward/back), then pan and tilt, then roll, then check the position once more (turning the mount head shifts the lens a little).
4. When it says `ALIGNED` and the frame is green, lock the mount and check that it is still green. Remove the board (for the side camera it blocks the view of the caps; it is only needed for placement).

Keys: `O` overlay, `+`/`-` transparency, `S` save the current pose as the new target (to bring the camera back if someone bumps it), `P` screenshot, `Q` quit.

Options: `--tol-cm 0.3 --tol-deg 0.3` tighter tolerance, `--smooth 15` more smoothing, `--image file.jpg` check a single photo.

## Two modes: by hand or with motors

**1. Manual (default).** The app only gives hints for all 6 axes; you move and turn by hand:
```bash
python align_camera.py --cam 0 --calib calib.json --target align_target/target.json
```

**2. With motors.** Position (right/up/forward) and roll are still hints for your hands, while pan and tilt are turned by the steppers:
```bash
python align_camera.py --cam 0 --calib calib.json --target align_target/target.json --motors
#   --motors COM3          if the port is not found automatically
#   --recal-motors         learn the motor directions again (after rebuilding the mount)
```
Press `A` to start or stop the motors. The pan/tilt rows in the window are marked `M`, the motor status is shown in blue at the bottom. Order: first set the position by hand following `NEXT:`, then `A`, then roll by hand. Close the Arduino IDE Serial Monitor first: only one program can use the COM port.

First run: the app turns each motor a little (about 8°) by itself and learns from the image which way it turns and how many steps make one degree. The result is written to `motors.json`; after that this step is skipped. So it does not matter how the motor is mounted (backwards, through a gear): it is all taken into account.

How the control works: measure (median of 8 frames) → turn by 85% of the error → measure again, until pan and tilt are within tolerance twice in a row. Then the motor current is switched off (the gearbox holds by itself). The firmware takes out gearbox backlash: every move ends in the same direction. Travel is limited in software (pan ±60°, tilt ±30°) so the cable does not get wound up.

### Wiring (no soldering)
| From | To |
|---|---|
| Nano D2, D3, D4, D5 | pan board: IN1, IN2, IN3, IN4 |
| Nano D6, D7, D8, D9 | tilt board: IN1, IN2, IN3, IN4 |
| 5 V supply "+" (terminal) | "+" on both ULN2003 boards |
| 5 V supply "−" (terminal) | "−" on both boards and GND on the Nano |
| Motor | into the white connector of its board |
| Nano USB | computer (data and power for the Nano itself) |

### Firmware (once)
1. Arduino IDE → Tools → Manage Libraries → install `AccelStepper`.
2. Open `firmware/pantilt/pantilt.ino`, Board: `Arduino Nano`, Processor: `ATmega328P` (if upload fails, `ATmega328P (Old Bootloader)`), pick the port, Upload.
3. Check: Serial Monitor at 115200, you should get `PANTILT READY`. The command `M 500 0` turns pan, reply `OK 500 0`. `R` switches the current off.
If the board does not show up in the system, install the CH340 driver.

### Check without hardware
```bash
python selftest_motors.py
```
Simulates a mount where pan is mounted backwards and through a gear, the gearbox has backlash and the camera has frame lag. The control runs through the real chain (image → board → solvePnP → motors). Result on 2026-10-25: both cases converged to 0.3° in 3 moves after calibration, PASS.

## Accuracy and limits
- On synthetic data ~1 mm and ~0.1°. With a real webcam I expect about 2–3 mm and 0.2–0.5° with the board ~40–60 cm from the camera. The bigger the board in the image, the better. If the board is far and small, print it larger (A3) and update `board.json`.
- The main source of error: how exactly the board stands where it stood in the twin, and how accurate the twin itself is.
- If the sim camera and the real one have different fields of view, the app still computes the pose correctly; the reference frame is reprojected for the real lens, but for training data it is better to do step 3b.
- The labels in the window are in English (OpenCV cannot draw Cyrillic).

## For the pitch
"Sim-first camera commissioning": the camera is designed in the digital twin together with the training data, and on the line a technician puts it into exactly the same pose in a couple of minutes by following the hints. So the model trained on renders from that pose sees the same picture on the line (smaller sim-to-real gap), and after a changeover, or if the camera gets bumped, it can be put back without a vision engineer. This maps directly onto the "changeovers" and "operator trust" criteria from Rockwell.
