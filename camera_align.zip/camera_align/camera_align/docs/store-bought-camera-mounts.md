# Store-bought camera mounts for the CSI visit (instead of the printed parts)

Written 2026-10-30. Same camera positions as the printed side_arm / diag_riser + diag_arm. Skip the motors today: aim by hand with the ball head and let camera_align tell you when it is right (no `--motors`).

## Shopping list

**Home Depot (or Lowe's / Menards)**
| Item | Qty | Why |
|---|---|---|
| Square U-bolt, 2 in inside width, 3/8-16, with plate and nuts (Everbilt). If only 1/4 in exist, take those. | 4 | Clamps around the 50 x 50 mm portal members (2 in = 50.8 mm), no T-nuts needed |
| Zinc slotted steel angle, 1-1/2 in x 36 in (Everbilt) | 1–2 | Arms and riser; bolt it anywhere through the slots |
| Hacksaw (if you do not have one) | 1 | Cut the angle to length |
| 1/4-20 x 3/4 in hex bolts, nuts, washers, lock washers (small pack) | ~10 | Angle to angle, ball head to angle |
| 1/4-20 wing nuts | 4 | Quick adjustments at the line |
| 4 in C-clamps or small quick-grip clamps | 2 | Backup if the U-bolts do not fit |
| Black electrical tape or zip ties | 1 | Cable strain relief |

**Best Buy / Walmart / Target (Home Depot usually has no camera parts)**
| Item | Qty | Why |
|---|---|---|
| Mini ball head with 1/4-20 screw on top and 1/4-20 hole underneath (or a cheap mini tripod and use its head) | 2 | Pan, tilt and roll adjustment. The C922 clip has a 1/4-20 thread. |

Get a ball head with a single locking knob, metal, rated ≥1 kg. Tighten it firmly; it must not sag over the day.

## SIDE camera (looks at the tray from +x, horizontal)
1. Put one U-bolt around **portal post P1** (the post nearer the tray end, toward −y), at about **430 mm above the top of the foot beam**.
2. Bolt a piece of angle (~200 mm) to the U-bolt plate so it sticks out **horizontally toward −y**, away from the robot.
3. Ball head on the angle about **120–125 mm out from the post face**, camera on the ball head, facing the tray (−x), level.
4. Lens height: about level with the **tops of the caps** (sim: lens 66 mm above the tray plate top). Raise or lower the U-bolt to get there.
5. Keep everything behind the lens. Nothing can stick out toward the tray or the robot.

## DIAG camera (hangs above, looks down 35° at the tray corner)
1. Put one U-bolt around the **portal top beam**, about **50 mm from post P2** (toward P1).
2. Bolt a vertical riser of angle (~200 mm) so it goes **up**.
3. Bolt a horizontal arm (~250 mm) to the top of the riser so it reaches **toward the tray (−x), about 150 mm past the beam centre**.
4. Hang the ball head **under** the arm end, camera upside down, pointing down-and-toward the tray, 35° below horizontal.
5. Lens about **80 mm above the top of the beam**. Slide the arm up or down the riser slots to get there.
6. Everything stays **above** the lens: the robot passes under it.
7. In the app use `--upside-down` for this camera (same as before).

## Aligning at the line
Same as planned, just by hand:
```
python align_camera.py --cam 0 --calib calib.json --target align_target/side/target.json --board align_target/side/board.json
python align_camera.py --cam 0 --calib calib.json --target align_target/diag/target.json --board align_target/diag/board.json --upside-down
```
Put the board holder on the tray. Turn the ball head until the angle rows are green, then slide the arms or U-bolts for x/y/z. Lock everything, check again, and press **P** for a screenshot as proof.

The positions matter more than the hardware. If something is ~1 cm off and cannot be fixed, take the screenshot and note it. The model has ±2 mm / ±0.2° of jitter in training, so get as close as you can.
