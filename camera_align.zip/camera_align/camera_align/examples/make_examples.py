"""Make example pictures of how the ChArUco board is used (renders + app screenshots)."""
import os
import sys

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

APP = "/mnt/project-files/tools/camera_align"
OUT = os.path.join(APP, "examples")
sys.path.insert(0, APP)
os.makedirs(OUT, exist_ok=True)
from align_camera import draw_panel, draw_poly, image_impact_px, pose_errors  # noqa: E402
from board import board_size_m, cam_pose_in_board, detect, estimate_pose, load_board, make_detector  # noqa: E402

board, cfg = load_board()
det = make_detector(board)
W, H = 1280, 720
K = np.array([[900.0, 0, W / 2], [0, 900.0, H / 2], [0, 0, 1]])
bw, bh = board_size_m(cfg)
rng = np.random.default_rng(0)
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONTB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"


def rot(axis, deg):
    r, _ = cv2.Rodrigues(np.asarray(axis, float) * np.radians(deg))
    return r


def render(T_board_cam, bg, ppm=2000):
    img = board.generateImage((int(bw * ppm), int(bh * ppm)), marginSize=0, borderBits=1)
    img = cv2.copyMakeBorder(img, 40, 40, 40, 40, cv2.BORDER_CONSTANT, value=255)   # white paper margin
    Tcb = np.linalg.inv(T_board_cam)
    Hm = K @ np.column_stack([Tcb[:3, 0], Tcb[:3, 1], Tcb[:3, 3]]) @ np.array(
        [[1 / ppm, 0, -40 / ppm], [0, 1 / ppm, -40 / ppm], [0, 0, 1]])
    warped = cv2.warpPerspective(img, Hm, (W, H), borderValue=0)
    mask = cv2.warpPerspective(np.full(img.shape, 255, np.uint8), Hm, (W, H), borderValue=0)
    out = np.where(mask > 0, warped, bg).astype(float)
    return cv2.cvtColor(np.clip(out + rng.normal(0, 3, out.shape), 0, 255).astype(np.uint8), cv2.COLOR_GRAY2BGR)


def background(kind):
    y, x = np.mgrid[0:H, 0:W]
    if kind == "side":   # back wall + table top, a fixture block on the table
        bg = np.where(y < 470, 150 + 0.02 * x, 95 + 0.05 * (y - 470)).astype(np.uint8)
        bg[300:470, 0:300] = 70
    else:                # tray seen from above with vial caps
        bg = np.full((H, W), 120, np.uint8)
        for cx in range(80, W, 110):
            for cy in (90, 630):
                cv2.circle(bg, (cx, cy), 38, 200, -1)
                cv2.circle(bg, (cx, cy), 38, 60, 3)
    return bg


def app_view(T_cur, T_tgt, up, kind, name, motors=None):
    img = render(T_cur, background(kind))
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ch_c, ch_i, _, _ = detect(det, gray)
    rvec, tvec, rerr = estimate_pose(board, ch_c, ch_i, K, np.zeros(5))
    T_est = cam_pose_in_board(rvec, tvec)
    e = pose_errors(T_est, T_tgt, up)
    draw_poly(img, T_tgt, K, cfg, (255, 0, 255), 2)
    draw_poly(img, T_est, K, cfg, (0, 255, 0), 2)
    dist_m = float(np.linalg.norm(np.linalg.inv(T_est)[:3, 3]))
    imp = image_impact_px(e, K[0, 0], dist_m, 0.5 * np.hypot(W, H))
    status = f"corners {len(ch_i)}  reproj {rerr:.2f}px  board at {dist_m*100:.0f} cm  magenta=target green=now"
    draw_panel(img, e, imp, 0.5, 0.5, status, motors)
    cv2.imwrite(os.path.join(OUT, name), img)
    print(name, {k: round(v, 2) for k, v in e.items()})


# ---- side camera: board standing upright against the end of the fixture, camera 45 cm in front
UP_V = np.array([0.0, -1.0, 0.0])
T_side = np.eye(4)
T_side[:3, :3] = rot([0, 1, 0], -4) @ rot([1, 0, 0], -3)
T_side[:3, 3] = [bw / 2 + 0.03, bh / 2 - 0.03, -0.45]
T_side_off = T_side.copy()
T_side_off[:3, :3] = rot([0, 1, 0], 3) @ T_side[:3, :3] @ rot([0, 0, 1], 2)
T_side_off[:3, 3] += [-0.025, 0.012, -0.04]
app_view(T_side_off, T_side, UP_V, "side", "2_side_camera_misplaced.png")
app_view(T_side, T_side, UP_V, "side", "3_side_camera_aligned.png")
T_side_m = T_side.copy()
T_side_m[:3, :3] = rot([0, 1, 0], 4) @ rot([1, 0, 0], 2.5) @ T_side[:3, :3]
app_view(T_side_m, T_side, UP_V, "side", "4_side_camera_motors.png",
         motors="motors: pan +3.9 deg, tilt -2.4 deg -> turning")

# ---- overhead camera: board lying face-up on the tray, camera 50 cm above looking down
UP_F = np.array([0.0, 0.0, -1.0])
T_top = np.eye(4)
T_top[:3, 3] = [bw / 2, bh / 2, -0.50]
T_top_off = T_top.copy()
T_top_off[:3, :3] = rot([0, 0, 1], 6) @ rot([1, 0, 0], 2)
T_top_off[:3, 3] += [0.03, -0.02, 0.05]
app_view(T_top_off, T_top, UP_F, "top", "5_overhead_camera_misplaced.png")


# ---- placement sketch (side view), Russian labels
S = Image.new("RGB", (1400, 640), "white")
d = ImageDraw.Draw(S)
f, fb, fs = ImageFont.truetype(FONT, 22), ImageFont.truetype(FONTB, 28), ImageFont.truetype(FONT, 18)


def arrow(p, q, col="black"):
    d.line([p, q], fill=col, width=3)
    v = np.subtract(q, p); v = v / np.linalg.norm(v); n = np.array([-v[1], v[0]])
    a = np.array(q) - 14 * v
    d.polygon([tuple(q), tuple(a + 7 * n), tuple(a - 7 * n)], fill=col)


# left: side camera
d.text((30, 20), "Боковая камера (вид сбоку)", font=fb, fill="black")
d.line([(30, 470), (660, 470)], fill="black", width=4); d.text((40, 478), "стол / конвейер", font=fs, fill="gray")
d.rectangle([60, 330, 300, 470], fill=(200, 200, 200), outline="black", width=2)
d.text((95, 385), "фикстура G", font=f, fill="black")
d.rectangle([300, 260, 312, 470], fill="black")
for i in range(9):
    d.rectangle([302, 262 + 23 * i, 310, 274 + 23 * i], fill="white" if i % 2 else "black")
d.text((322, 230), "доска ChArUco", font=f, fill=(170, 0, 170))
d.text((322, 258), "стоит вертикально,", font=fs, fill="black")
d.text((322, 280), "плотно к торцу фикстуры,", font=fs, fill="black")
d.text((322, 302), "нижний край на столе", font=fs, fill="black")
d.rectangle([560, 360, 600, 470], fill=(120, 120, 120)); d.text((500, 520), "стойка 4040 + pan/tilt", font=fs, fill="black")
d.rectangle([540, 320, 620, 360], fill=(40, 40, 40)); d.text((630, 326), "C922", font=f, fill="black")
arrow((540, 340), (320, 380), (0, 140, 0))
d.text((380, 400), "~45 см", font=f, fill=(0, 140, 0))

# right: overhead camera
x0 = 740
d.text((x0, 20), "Верхняя камера (вид сбоку)", font=fb, fill="black")
d.line([(x0, 470), (x0 + 620, 470)], fill="black", width=4)
d.rectangle([x0 + 60, 440, x0 + 520, 470], fill=(200, 200, 200), outline="black", width=2)
d.text((x0 + 70, 478), "лоток с флаконами", font=fs, fill="gray")
d.rectangle([x0 + 200, 428, x0 + 380, 440], fill="black")
for i in range(8):
    d.rectangle([x0 + 202 + 22 * i, 430, x0 + 214 + 22 * i, 438], fill="white" if i % 2 else "black")
d.text((x0 + 170, 380), "доска лежит плашмя,", font=fs, fill=(170, 0, 170))
d.text((x0 + 170, 402), "лицом вверх, в углу лотка", font=fs, fill=(170, 0, 170))
d.rectangle([x0 + 250, 110, x0 + 330, 150], fill=(40, 40, 40)); d.text((x0 + 345, 115), "C922", font=f, fill="black")
arrow((x0 + 290, 150), (x0 + 290, 370), (0, 140, 0))
d.text((x0 + 300, 250), "~50 см", font=f, fill=(0, 140, 0))

d.text((30, 570), "Главное правило: в двойнике (Isaac Sim) и на линии доска стоит В ОДНОМ И ТОМ ЖЕ месте.", font=f, fill="black")
d.text((30, 600), "Упирай её в торец, угол или упор, а не ставь на глаз: ошибка доски = такая же ошибка камеры.", font=fs, fill="black")
S.save(os.path.join(OUT, "1_where_to_put_the_board.png"))
print("done")
