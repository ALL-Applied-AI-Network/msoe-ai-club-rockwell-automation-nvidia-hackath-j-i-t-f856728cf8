// Pan/tilt driver for camera_align: Arduino Nano + 2x 28BYJ-48 + 2x ULN2003.
// Needs the AccelStepper library (Arduino IDE: Tools > Manage Libraries > "AccelStepper").
//
// Wiring (ULN2003 IN1..IN4):  pan  -> D2 D3 D4 D5      tilt -> D6 D7 D8 D9
// ULN2003 "+" / "-" go to the 5 V supply; supply "-" must also go to Nano GND.
//
// Serial 115200, one command per line:
//   M <pan> <tilt>   relative move in half-steps (both axes at once), replies "OK <pan_pos> <tilt_pos>"
//   R                release coils (motor cools down, gearbox holds the position), replies "OK"
//   ?                replies "POS <pan_pos> <tilt_pos>"
// Every move ends going in the + direction (overshoot by BACKLASH, then come back),
// so gearbox play is always taken up the same way and the camera lands where it is told.

#include <AccelStepper.h>

const long BACKLASH = 60;        // half-steps (~5 deg of motor shaft) > gearbox play of a 28BYJ-48
const float MAX_SPEED = 700;     // half-steps/s, 28BYJ-48 at 5 V stalls above ~900
const float ACCEL = 600;

// HALF4WIRE wants the pins in the order IN1, IN3, IN2, IN4
AccelStepper pan(AccelStepper::HALF4WIRE, 2, 4, 3, 5);
AccelStepper tilt(AccelStepper::HALF4WIRE, 6, 8, 7, 9);

long finalPan = 0, finalTilt = 0;  // targets of the second (approach) phase
bool busy = false, phase2 = false;
char line[40];
byte len = 0;

void setupAxis(AccelStepper &m) {
  m.setMaxSpeed(MAX_SPEED);
  m.setAcceleration(ACCEL);
  m.disableOutputs();
}

// First phase: go past the target on the - side when moving backwards.
void startMove(long dp, long dt) {
  finalPan = pan.currentPosition() + dp;
  finalTilt = tilt.currentPosition() + dt;
  pan.enableOutputs();
  tilt.enableOutputs();
  pan.moveTo(dp < 0 ? finalPan - BACKLASH : finalPan);
  tilt.moveTo(dt < 0 ? finalTilt - BACKLASH : finalTilt);
  busy = true;
  phase2 = false;
}

void reply() {
  Serial.print("OK ");
  Serial.print(pan.currentPosition());
  Serial.print(' ');
  Serial.println(tilt.currentPosition());
}

void handle(char *s) {
  if (s[0] == 'M') {
    char *p = s + 1;
    long dp = strtol(p, &p, 10);
    long dt = strtol(p, &p, 10);
    startMove(dp, dt);
  } else if (s[0] == 'R') {
    pan.disableOutputs();
    tilt.disableOutputs();
    Serial.println("OK");
  } else if (s[0] == '?') {
    Serial.print("POS ");
    Serial.print(pan.currentPosition());
    Serial.print(' ');
    Serial.println(tilt.currentPosition());
  } else if (len > 0) {
    Serial.println("ERR unknown command");
  }
}

void setup() {
  Serial.begin(115200);
  setupAxis(pan);
  setupAxis(tilt);
  Serial.println("PANTILT READY");
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') {
      line[len] = 0;
      if (len > 0 && !busy) handle(line);
      else if (len > 0) Serial.println("ERR busy");
      len = 0;
    } else if (len < sizeof(line) - 1) {
      line[len++] = c;
    }
  }

  if (!busy) return;
  bool running = pan.run() | tilt.run();   // not ||: both must step
  if (running) return;
  if (!phase2) {
    phase2 = true;
    pan.moveTo(finalPan);
    tilt.moveTo(finalTilt);
    return;
  }
  busy = false;
  reply();   // coils stay on until R so the camera can settle and be measured
}
