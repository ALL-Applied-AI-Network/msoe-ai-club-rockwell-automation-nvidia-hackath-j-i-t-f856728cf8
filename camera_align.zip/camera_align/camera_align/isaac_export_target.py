"""Isaac Sim side of the camera-alignment tool.

1) add-board : put the same printed ChArUco board into the twin (textured quad, true size) at a spot
               you can reproduce on the real line (e.g. standing upright against the end of the fixture).
2) apply-calib: (optional) give the sim camera the real webcam's field of view from calib.json.
3) export    : save target.json (pose of the sim camera relative to the board, OpenCV convention)
               + target_ref.png (what the camera should see) for align_camera.py.

Headless (Brev / DGX Spark):
  /isaac-sim/python.sh isaac_export_target.py add-board --stage jit_scene.usd \
        --board-pos 0.62 0.10 0.80 --board-rot 90 0 -90          # metres / degrees (XYZ), see README
  /isaac-sim/python.sh isaac_export_target.py apply-calib --stage jit_scene.usd --camera /World/SideCam \
        --calib calib.json
  /isaac-sim/python.sh isaac_export_target.py export --stage jit_scene.usd --camera /World/SideCam \
        --width 1280 --height 720 --out-dir align_target
GUI (Window > Script Editor): see gui_snippet() at the bottom.

AlignBoard prim convention (USD): origin = board centre, +X = board right, +Y = board up (text upright),
+Z = out of the printed face, toward whoever looks at it. The quad is drawn so it reads correctly from +Z.
"""
import argparse
import json
import os
import shutil
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
BOARD_PRIM = "/World/AlignBoard"


# ---------------------------------------------------------------- pure USD maths (works with plain usd-core)
def _board_cfg(path=None):
    with open(path or os.path.join(HERE, "board.json")) as f:
        return json.load(f)


def _world_matrix(stage, path):
    """4x4 local->world, column-vector convention, translation in METRES, rotation without scale."""
    from pxr import Usd, UsdGeom
    prim = stage.GetPrimAtPath(path)
    if not prim.IsValid():
        raise RuntimeError(f"prim {path} not found")
    M = np.array(UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(Usd.TimeCode.Default()), float).T
    mpu = UsdGeom.GetStageMetersPerUnit(stage) or 1.0
    R = M[:3, :3] / np.linalg.norm(M[:3, :3], axis=0)          # strip scale
    U, _, Vt = np.linalg.svd(R)                                 # re-orthonormalise
    T = np.eye(4); T[:3, :3] = U @ Vt; T[:3, 3] = M[:3, 3] * mpu
    return T


def sim_intrinsics(stage, cam_path, width, height):
    from pxr import UsdGeom
    cam = UsdGeom.Camera(stage.GetPrimAtPath(cam_path))
    f = cam.GetFocalLengthAttr().Get()
    ha = cam.GetHorizontalApertureAttr().Get()
    hoff = cam.GetHorizontalApertureOffsetAttr().Get() or 0.0
    voff = cam.GetVerticalApertureOffsetAttr().Get() or 0.0
    fx = f / ha * width                       # RTX renders square pixels: fy = fx
    # an aperture offset moves the film window, so the principal point moves the opposite way
    # (checked on RTX 2026-10-29: the old signs put the reference image 50 px off its own K)
    return np.array([[fx, 0, width / 2 - hoff / ha * width],
                     [0, fx, height / 2 + voff / ha * width],
                     [0, 0, 1]])


def compute_target(stage, cam_path, board_path=BOARD_PRIM, board_json=None):
    """Return (T_board_cam, up_in_board) in the OpenCV conventions used by align_camera.py."""
    from pxr import UsdGeom
    cfg = _board_cfg(board_json)
    w = cfg["squares_x"] * cfg["square_length_m"]
    h = cfg["squares_y"] * cfg["square_length_m"]
    # OpenCV board frame (origin top-left corner, x right, y down, z into the board) in AlignBoard coords
    A = np.array([[1, 0, 0, -w / 2], [0, -1, 0, h / 2], [0, 0, -1, 0], [0, 0, 0, 1]], float)
    T_world_board = _world_matrix(stage, board_path) @ A
    # USD camera looks down -Z with +Y up; OpenCV camera looks down +Z with +Y down
    T_world_cam = _world_matrix(stage, cam_path) @ np.diag([1, -1, -1, 1])
    T_board_cam = np.linalg.inv(T_world_board) @ T_world_cam
    up_world = np.array([0, 0, 1.0]) if UsdGeom.GetStageUpAxis(stage) == "Z" else np.array([0, 1.0, 0])
    up_in_board = T_world_board[:3, :3].T @ up_world
    return T_board_cam, up_in_board


def add_board(stage, pos_m, rot_deg, board_png, board_json=None, path=BOARD_PRIM):
    """Create/replace the AlignBoard: an Xform with a true-size textured quad."""
    from pxr import Gf, Sdf, UsdGeom, UsdShade, Vt
    cfg = _board_cfg(board_json)
    mpu = UsdGeom.GetStageMetersPerUnit(stage) or 1.0
    w = cfg["squares_x"] * cfg["square_length_m"] / mpu
    h = cfg["squares_y"] * cfg["square_length_m"] / mpu
    if stage.GetPrimAtPath(path):
        stage.RemovePrim(path)
    xf = UsdGeom.Xform.Define(stage, path)
    xf.AddTranslateOp().Set(Gf.Vec3d(*[p / mpu for p in pos_m]))
    xf.AddRotateXYZOp().Set(Gf.Vec3f(*rot_deg))

    mesh = UsdGeom.Mesh.Define(stage, path + "/Quad")
    mesh.CreatePointsAttr([(-w / 2, -h / 2, 0), (w / 2, -h / 2, 0), (w / 2, h / 2, 0), (-w / 2, h / 2, 0)])
    mesh.CreateFaceVertexCountsAttr([4])
    mesh.CreateFaceVertexIndicesAttr([0, 1, 2, 3])               # counter-clockwise seen from +Z
    mesh.CreateNormalsAttr([(0, 0, 1)] * 4)
    mesh.SetNormalsInterpolation(UsdGeom.Tokens.vertex)
    mesh.CreateDoubleSidedAttr(False)
    st = UsdGeom.PrimvarsAPI(mesh).CreatePrimvar("st", Sdf.ValueTypeNames.TexCoord2fArray,
                                                 UsdGeom.Tokens.vertex)
    st.Set(Vt.Vec2fArray([(0, 0), (1, 0), (1, 1), (0, 1)]))

    mat = UsdShade.Material.Define(stage, path + "/Mat")
    sh = UsdShade.Shader.Define(stage, path + "/Mat/Surface")
    sh.CreateIdAttr("UsdPreviewSurface")
    sh.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(0.9)   # matte paper, little glare
    sh.CreateInput("metallic", Sdf.ValueTypeNames.Float).Set(0.0)
    rd = UsdShade.Shader.Define(stage, path + "/Mat/StReader")
    rd.CreateIdAttr("UsdPrimvarReader_float2")
    rd.CreateInput("varname", Sdf.ValueTypeNames.Token).Set("st")
    tex = UsdShade.Shader.Define(stage, path + "/Mat/Tex")
    tex.CreateIdAttr("UsdUVTexture")
    tex.CreateInput("file", Sdf.ValueTypeNames.Asset).Set(board_png)
    tex.CreateInput("sourceColorSpace", Sdf.ValueTypeNames.Token).Set("sRGB")
    tex.CreateInput("st", Sdf.ValueTypeNames.Float2).ConnectToSource(rd.ConnectableAPI(), "result")
    sh.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).ConnectToSource(tex.ConnectableAPI(), "rgb")
    mat.CreateSurfaceOutput().ConnectToSource(sh.ConnectableAPI(), "surface")
    UsdShade.MaterialBindingAPI.Apply(mesh.GetPrim()).Bind(mat)
    return path


def apply_calib(stage, cam_path, calib_path):
    """Give the sim camera the real lens' horizontal FOV (keeps its aperture, changes focal length)."""
    from pxr import UsdGeom
    with open(calib_path) as f:
        c = json.load(f)
    K, (W, H) = np.array(c["K"]), c["image_size"]
    cam = UsdGeom.Camera(stage.GetPrimAtPath(cam_path))
    ha = cam.GetHorizontalApertureAttr().Get()
    cam.GetFocalLengthAttr().Set(float(K[0, 0] / W * ha))
    cam.GetVerticalApertureAttr().Set(float(ha * H / W))
    print(f"{cam_path}: focal {K[0,0]/W*ha:.3f} (aperture {ha}), HFOV {c.get('hfov_deg', 0):.1f} deg")


def write_target(out_dir, T_board_cam, up, K, size, ref_name="target_ref.png", cam_path=""):
    os.makedirs(out_dir, exist_ok=True)
    d = float(np.linalg.norm(T_board_cam[:3, 3]))
    out = {"source": "isaac_sim", "camera_prim": cam_path, "T_board_cam": T_board_cam.tolist(),
           "up_in_board": [float(x) for x in up], "intrinsics": {"K": K.tolist(), "image_size": list(size)},
           "reference_image": ref_name, "camera_to_board_m": d}
    shutil.copy(os.path.join(HERE, "board.json"), os.path.join(out_dir, "board.json"))
    with open(os.path.join(out_dir, "target.json"), "w") as f:
        json.dump(out, f, indent=2)
    print(f"wrote {out_dir}/target.json (camera {d*100:.1f} cm from the board corner)")


# ---------------------------------------------------------------- rendering (needs Isaac Sim)
def render_reference(cam_path, width, height, out_png, warmup=20):
    import omni.replicator.core as rep
    from PIL import Image
    rp = rep.create.render_product(cam_path, (width, height))
    ann = rep.AnnotatorRegistry.get_annotator("rgb")
    ann.attach(rp)
    for _ in range(warmup):                     # let RTX converge / textures load
        rep.orchestrator.step(rt_subframes=4)
    rgba = ann.get_data()
    Image.fromarray(np.asarray(rgba)[:, :, :3]).save(out_png)
    ann.detach(); rp.destroy()
    print(f"wrote {out_png}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["add-board", "apply-calib", "export"])
    ap.add_argument("--stage", required=True)
    ap.add_argument("--camera", default="/World/SideCam")
    ap.add_argument("--board-pos", type=float, nargs=3, metavar=("X", "Y", "Z"), help="metres, world")
    ap.add_argument("--board-rot", type=float, nargs=3, default=[90, 0, -90], metavar=("RX", "RY", "RZ"),
                    help="degrees XYZ. Default (Z-up stage): board upright, printed face toward -X")
    ap.add_argument("--calib", default="calib.json")
    ap.add_argument("--width", type=int, default=1280)
    ap.add_argument("--height", type=int, default=720)
    ap.add_argument("--out-dir", default="align_target")
    ap.add_argument("--no-render", action="store_true", help="export pose only (no Isaac Sim needed)")
    a = ap.parse_args()

    need_app = a.cmd == "export" and not a.no_render
    app = None
    if need_app:
        from isaacsim import SimulationApp
        app = SimulationApp({"headless": True, "width": a.width, "height": a.height})
        import omni.usd
        omni.usd.get_context().open_stage(a.stage)
        for _ in range(10):
            app.update()
        stage = omni.usd.get_context().get_stage()
    else:
        from pxr import Usd
        stage = Usd.Stage.Open(a.stage)

    if a.cmd == "add-board":
        if not a.board_pos:
            sys.exit("--board-pos X Y Z is required")
        png = os.path.join(os.path.dirname(os.path.abspath(a.stage)), "align_board.png")
        shutil.copy(os.path.join(HERE, "board.png"), png)
        add_board(stage, a.board_pos, a.board_rot, png)
        stage.GetRootLayer().Save()
        print(f"added {BOARD_PRIM} to {a.stage}; texture {png}")
    elif a.cmd == "apply-calib":
        apply_calib(stage, a.camera, a.calib)
        stage.GetRootLayer().Save()
    else:
        T, up = compute_target(stage, a.camera)
        K = sim_intrinsics(stage, a.camera, a.width, a.height)
        write_target(a.out_dir, T, up, K, (a.width, a.height), cam_path=a.camera)
        if app:
            render_reference(a.camera, a.width, a.height, os.path.join(a.out_dir, "target_ref.png"))
    if app:
        app.close()


def gui_snippet():
    """Paste into Window > Script Editor (with this folder on sys.path) to export from the open scene:

    import sys; sys.path.append("/path/to/camera_align")
    import asyncio, numpy as np, omni.usd, omni.replicator.core as rep
    from PIL import Image
    import isaac_export_target as X
    CAM, W, H, OUT = "/World/SideCam", 1280, 720, "/path/to/align_target"
    stage = omni.usd.get_context().get_stage()
    # X.add_board(stage, [0.62, 0.10, 0.80], [90, 0, -90], "/path/to/camera_align/board.png")  # once
    T, up = X.compute_target(stage, CAM)
    X.write_target(OUT, T, up, X.sim_intrinsics(stage, CAM, W, H), (W, H), cam_path=CAM)
    async def grab():
        rp = rep.create.render_product(CAM, (W, H)); ann = rep.AnnotatorRegistry.get_annotator("rgb")
        ann.attach(rp)
        for _ in range(20):
            await rep.orchestrator.step_async(rt_subframes=4)
        Image.fromarray(np.asarray(ann.get_data())[:, :, :3]).save(OUT + "/target_ref.png")
        ann.detach(); rp.destroy(); print("saved reference image")
    asyncio.ensure_future(grab())
    """


if __name__ == "__main__":
    main()
