"""Write the ChArUco board as a PNG to print (and to use as the texture in Isaac Sim).

  python make_board.py                 -> board.png at 300 dpi, true size
Print at 100% / "actual size" (NOT "fit to page"), then measure a square and update board.json.
"""
import argparse

import cv2

from board import board_size_m, load_board

ap = argparse.ArgumentParser()
ap.add_argument("--out", default="board.png")
ap.add_argument("--dpi", type=int, default=300)
ap.add_argument("--board", default=None, help="board.json path")
a = ap.parse_args()

board, cfg = load_board(a.board)
w_m, h_m = board_size_m(cfg)
px_per_m = a.dpi / 0.0254
size = (int(round(w_m * px_per_m)), int(round(h_m * px_per_m)))
img = board.generateImage(size, marginSize=0, borderBits=1)
cv2.imwrite(a.out, img, [cv2.IMWRITE_PNG_COMPRESSION, 9])
try:  # a PDF with the physical size baked in prints at true scale more reliably than a PNG
    from PIL import Image
    pdf = a.out.rsplit(".", 1)[0] + ".pdf"
    Image.fromarray(img).convert("L").save(pdf, resolution=a.dpi)
    print(f"wrote {pdf}")
except ImportError:
    pass
print(f"wrote {a.out}: {size[0]}x{size[1]} px = {w_m*100:.1f} x {h_m*100:.1f} cm at {a.dpi} dpi")
print("Print at 100% scale, glue to something flat and stiff (foam board / clipboard).")
