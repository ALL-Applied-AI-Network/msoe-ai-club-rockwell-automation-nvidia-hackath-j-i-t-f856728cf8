"""Motorised pan/tilt for align_camera.py (Arduino Nano + 2x 28BYJ-48, firmware/pantilt/pantilt.ino).

The camera image is the feedback: after every move the app measures the pose again, so the motors
need no encoders and the mechanics need no exact gear ratio. Before the first run the controller
nudges each motor once to learn how many steps make one degree and which way is which
(saved to motors.json, so this happens only once per rig).
"""
import json
import os
import time

import numpy as np

CH340_VID, ARDUINO_VID = 0x1A86, 0x2341


def find_port():
    from serial.tools import list_ports
    ports = list(list_ports.comports())
    for p in ports:
        if p.vid in (CH340_VID, ARDUINO_VID):
            return p.device
    if len(ports) == 1:
        return ports[0].device
    raise RuntimeError("Arduino not found, pass --motors COM3 (or /dev/ttyUSB0). Seen: "
                       + ", ".join(p.device for p in ports))


class SerialPanTilt:
    """Non-blocking link to the firmware: move() sends, poll() returns True once the move is done."""

    def __init__(self, port=None, baud=115200):
        import serial
        self.port = port or find_port()
        self.ser = serial.Serial(self.port, baud, timeout=0)
        self.buf = b""
        self.busy = False
        # opening the port resets the Nano: wait for its greeting
        t0 = time.time()
        while time.time() - t0 < 4:
            if any(l.startswith("PANTILT READY") for l in self._lines()):
                break
            time.sleep(0.05)
        else:
            print(f"warning: no 'PANTILT READY' from {self.port}, is pantilt.ino flashed?")

    def _lines(self):
        self.buf += self.ser.read(256)
        *done, self.buf = self.buf.split(b"\n")
        return [l.decode(errors="replace").strip() for l in done]

    def move(self, d_pan, d_tilt):
        self.ser.write(f"M {int(d_pan)} {int(d_tilt)}\n".encode())
        self.busy = True

    def poll(self):
        for l in self._lines():
            if l.startswith("OK"):
                self.busy = False
            elif l.startswith("ERR"):
                print("firmware:", l)
                self.busy = False
        return not self.busy

    def release(self):
        self.ser.write(b"R\n")

    def close(self):
        self.release()
        self.ser.close()


class AutoPanTilt:
    """Closed-loop pan/tilt: feed it the per-frame errors from pose_errors(), it drives the motors.

    States: idle -> calib_pan -> calib_tilt -> run -> done.   start() / stop() switch it on and off.
    """

    def __init__(self, link, tol_deg=0.5, cal_path="motors.json", recalibrate=False,
                 cal_steps=120, gain=0.85, max_step_deg=15.0, range_deg=(120.0, 60.0),
                 skip_frames=5, avg_frames=8):
        self.link, self.tol = link, tol_deg
        self.cal_path, self.cal_steps, self.gain = cal_path, cal_steps, gain
        self.max_step_deg, self.range_deg = max_step_deg, range_deg
        self.skip_frames, self.avg_frames = skip_frames, avg_frames
        # k = how many degrees the measured error changes per +1 motor step (sign included)
        self.k = None
        if not recalibrate and cal_path and os.path.exists(cal_path):
            with open(cal_path) as f:
                c = json.load(f)
            self.k = np.array([c["pan_deg_per_step"], c["tilt_deg_per_step"]])
        self.state = "idle"
        self.msg = "motors: press A for auto pan/tilt"
        self.steps = np.zeros(2)          # total steps since start, for the soft travel limits
        self._reset_samples()

    # ---------------------------------------------------------------- public
    def start(self):
        self.state = "run" if self.k is not None else "calib_pan"
        self.good_rounds = 0
        self.e0 = None
        self._reset_samples()
        self.msg = "motors: measuring..."

    def stop(self, msg="motors: stopped (A = start)"):
        self.state = "idle"
        self.link.release()
        self.msg = msg

    @property
    def active(self):
        return self.state not in ("idle", "done")

    def update(self, e):
        """Call once per frame. e = pose_errors() for that frame (unsmoothed), or None if no board."""
        if not self.active:
            return
        if self.link.busy and not self.link.poll():
            return                                   # still moving
        if e is None:
            return
        if self.skip > 0:                            # frames still in the camera buffer from before the move
            self.skip -= 1
            return
        self.samples.append((e["pan_deg"], e["tilt_deg"]))
        if len(self.samples) < self.avg_frames:
            return
        err = np.median(np.array(self.samples), axis=0)
        self._reset_samples()
        getattr(self, "_" + self.state)(err)

    # ---------------------------------------------------------------- states
    def _calib(self, err, axis, nxt):
        name = "pan" if axis == 0 else "tilt"
        if self.e0 is None:                          # take up the gearbox play first, measure after
            self.e0 = "play"
            self._move(axis, self.cal_steps // 2)
            self.msg = f"motors: learning {name} direction..."
            return
        if isinstance(self.e0, str):                 # play taken up: this is the start point
            self.e0 = err
            self._move(axis, self.cal_steps)
            return
        k = (err[axis] - self.e0[axis]) / self.cal_steps
        if abs(k) < 0.01:                            # < 1.2 deg for 120 half-steps: did not turn
            self.stop(f"motors: {name} did not move - check wiring/power")
            return
        if self.k is None:
            self.k = np.zeros(2)
        self.k[axis] = k
        self.e0 = None
        self.state = nxt
        if nxt == "run":
            self._save()
        self._run(err) if nxt == "run" else self._calib_tilt(err)

    def _calib_pan(self, err):
        self._calib(err, 0, "calib_tilt")

    def _calib_tilt(self, err):
        self._calib(err, 1, "run")

    def _run(self, err):
        bad = np.abs(err) > self.tol
        if not bad.any():
            self.good_rounds += 1
            if self.good_rounds >= 2:                # twice in a row: really there
                self.state = "done"
                self.link.release()
                self.msg = "motors: pan/tilt ALIGNED, coils off (A = run again)"
            return
        self.good_rounds = 0
        # steps that cancel the error: err + k*steps = 0
        d = np.where(bad, -self.gain * err / self.k, 0.0)
        lim = self.max_step_deg / np.abs(self.k)
        d = np.clip(d, -lim, lim)
        rng = np.array(self.range_deg) / 2 / np.abs(self.k)
        d = np.clip(self.steps + d, -rng, rng) - self.steps    # soft limit: keep the cable safe
        d = np.round(d)
        if not d.any():
            self.stop("motors: at travel limit or below one step - move the rig by hand")
            return
        self.steps += d
        self.link.move(d[0], d[1])
        self.msg = f"motors: pan {err[0]:+.1f} deg, tilt {err[1]:+.1f} deg -> turning"

    # ---------------------------------------------------------------- helpers
    def _move(self, axis, n):
        d = [0, 0]
        d[axis] = n
        self.steps += d
        self.link.move(*d)

    def _reset_samples(self):
        self.samples = []
        self.skip = self.skip_frames

    def _save(self):
        if not self.cal_path:
            return
        with open(self.cal_path, "w") as f:
            json.dump({"pan_deg_per_step": float(self.k[0]), "tilt_deg_per_step": float(self.k[1])}, f, indent=2)
        print(f"motor calibration saved to {self.cal_path}: {self.k[0]:+.4f} / {self.k[1]:+.4f} deg per step")
