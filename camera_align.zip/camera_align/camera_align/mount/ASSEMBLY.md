# Pan-tilt camera mount: build guide

For the side camera rig (Logitech C922) on the 4040 profile cantilever. Two 28BYJ-48 steppers turn pan and tilt; the app (`align_camera.py --motors`) drives them using the camera image as feedback. Roll is set by hand on a small rocker plate (±10°, one lock screw) for now.

![assembly](assembly.png)

Files in this folder:

| File | What |
|---|---|
| `pantilt_mount.scad` | Parametric source (OpenSCAD, free). All sizes are at the top. |
| `stl/*.stl` | Ready parts, already rotated for printing, no supports needed |
| `assembly.png`, `assembly_back.png` | Renders of the assembled mount |

How it works mechanically: each motor only **turns** its axis, the **608 bearing carries the weight**. Pan: the turntable sits on a bearing in the base, the pan motor shaft pokes up into the turntable from below. Tilt: the cradle hangs between two uprights, motor shaft on the left, a short 8 mm steel rod in a bearing on the right. The tilt axis goes through the middle of the camera, so the motor barely has to hold anything.

Main sizes: base 60 × 60 mm (flange 84 × 84), turntable 144 × 50 mm, tilt axis 52 mm above the turntable, about 112 mm tall overall. Moving camera load ≈ 205 g (C922 162 g + cradle + roll plate).

---

## 0. What you need

You already have: 5× 28BYJ-48 + 5× ULN2003 (2 used, 3 spare), 5 V supply, the C922, the printer.

Still needed :

| Part | Qty | Used for |
|---|---|---|
| 608ZZ bearing (8 × 22 × 7) | 2 | pan + tilt |
| Arduino Nano + USB cable | 1 | controller |
| DC jack → screw terminal adapter | 1 | 5 V supply into the boards |
| Dupont wires female-female | ~12 | Nano ↔ ULN2003 |
| M3 × 8 screw | 2 | pan motor into the base (cuts its own thread) |
| M3 × 10 screw + nut | 2 + 2 | tilt motor to its upright |
| M3 × 12 screw + nut | 4 + 4 | uprights to turntable |
| M3 × 6 screw (grub or any short one) | 1 | locks the tilt rod |
| 8 mm steel rod, 12.5 mm piece | 1 | tilt axle (cut from the profile rods) |
| 1/4"-20 × 10 mm screw + washer | 1 | camera onto the roll plate |
| M3 × 10 screw + washer | 1 | roll lock |
| M4 screws (or whatever the carriage takes) | 4 | base to carriage, 70 mm square pattern |

Tools: hacksaw or Dremel for the rod, small file, 8 mm drill bit (to clean holes by hand), screwdriver, superglue (optional).

## 1. Print the fit test first (10 min)

Print `stl/fit_test.stl`. Then check:

| Hole | Should | If not, change in `.scad` |
|---|---|---|
| Large pocket | 608 presses in with your thumb and stays | `BRG_POCKET` ±0.05 |
| 8 mm hole | rod goes in tight, by pressing or light tapping | `ROD_HOLE` ±0.05 |
| (no test) | turntable spigot is snug in the bearing bore | `SPIGOT_D` (7.95) |
| D-hole | slides on the motor shaft, no wobble | `D_ROUND`, `D_FLAT` ±0.05. Loose? print `d_test` (3 holes, 1–3 dots = tighter) and pick the one that fits |
| Two small holes | M3 screws into the small one, passes the bigger one | `SCREW_TAP`, `SCREW_FREE` |

Also measure your motor with calipers: shaft length from the mounting face (`M_SHAFT`, default 10 mm) and ear hole spacing (`M_EAR`, 35 mm). These vary a bit between batches.

To export after a change: open `pantilt_mount.scad` in OpenSCAD, set `part = "cradle";` (etc.) at the top, F6, File → Export STL. Or from a terminal:
```bash
openscad -D 'part="cradle"' -o cradle.stl pantilt_mount.scad
```

## 2. Print the parts

PETG, 0.2 mm layers, 4 walls, 30–40 % infill, no supports. The STLs are already lying the right way; do not rotate them.

| Part | Orientation (already set) | Notes |
|---|---|---|
| `pan_base` | roof on the bed | bearing pocket has a lead-in chamfer against elephant foot |
| `turntable` | spigot pointing up | 144 mm long |
| `upright_motor` | inner face on the bed, foot sticking up | nut traps are on the bed side |
| `upright_bearing` | same | |
| `cradle` | floor on the bed | the two side holes are horizontal: clean them with an 8 mm drill by hand |
| `roll_plate` | flat top on the bed, curved side up | sand the curved side lightly so it rocks smoothly |

All fit on a 255 mm bed together. Total print time is roughly 5–7 hours.

## 3. Electronics on the bench (before any mechanics)

Test the motors loose on the table first. If something is wrong it is much easier to find now.

**Wiring** (no soldering, Dupont wires):

```
                 +---------------------+
   USB to PC ----|    Arduino Nano     |
                 | D2 D3 D4 D5  D6 D7 D8 D9  GND
                 +--|--|--|--|---|--|--|--|---|--+
                    |  |  |  |   |  |  |  |   |
              IN1 IN2 IN3 IN4  IN1 IN2 IN3 IN4 |
             +----------------+ +----------------+
             | ULN2003  "PAN" | | ULN2003 "TILT" |
             |  +   -   [motor]| |  +   -  [motor]|
             +--|---|---------+ +--|---|---------+
                |   |              |   |
   5 V supply + +---|--------------+   |
   5 V supply - ----+------------------+---- also to Nano GND (above)
```

| From | To |
|---|---|
| Nano D2, D3, D4, D5 | PAN board IN1, IN2, IN3, IN4 |
| Nano D6, D7, D8, D9 | TILT board IN1, IN2, IN3, IN4 |
| 5 V supply + | "+" on both ULN2003 boards |
| 5 V supply − | "−" on both boards **and** Nano GND |
| Each motor | white connector on its board (only fits one way) |

Rules: the motors never take power from the Nano's 5 V pin, and the grounds must be shared or the motors twitch randomly. Keep the jumper on the ULN2003 board (it is the motor power switch). Label one board PAN and the other TILT with tape now.

**Flash and test:**
1. Arduino IDE → Tools → Manage Libraries → install `AccelStepper`.
2. Open `../firmware/pantilt/pantilt.ino`. Board: Arduino Nano, Processor: ATmega328P (if upload fails: "Old Bootloader"). Upload. If the port does not show up, install the CH340 driver.
3. Serial Monitor, 115200, line ending "Newline". You should see `PANTILT READY`.
4. Type `M 500 0` → pan motor turns ~44° and answers `OK 500 0`. `M -500 0` turns back (with a small overshoot and return, that is the anti-backlash move, it is normal).
5. `M 0 500` → tilt motor turns. `R` turns the coils off.

The four LEDs on a board blink when it works. LEDs blink but the shaft only buzzes: an IN wire is in the wrong order. Nothing at all: check the 5 V and the shared GND.

## 4. Mechanical assembly

**Step 1. Pan bearing.** Press a 608 into the pocket on top of `pan_base`. It must sit flush with the top surface. Use a flat piece of wood and press evenly, don't hammer the inner ring.

**Step 2. Pan motor.** From below, push the motor up into the base so the shaft comes up through the centre of the bearing (it does not touch the bearing, the bore is 8 mm and the shaft 5 mm). The blue wire cap points toward the wire slot. Fix the two ears with M3 × 8 screws into the blind holes. Pull the wire out through the slot.

**Step 3. Turntable.** Turn the motor shaft by hand so the flats match the D-hole in the turntable spigot. Push the spigot down into the bearing bore. It should sit on the bearing's **inner ring** only, with a ~0.5 mm gap between turntable and base. Turn it by hand: it turns the motor (stiff because of the gearbox, that is fine) and nothing rubs.

**Step 4. Tilt bearing.** Press the second 608 into `upright_bearing` from the outer side (the side with the big pocket).

**Step 5. Tilt rod.** Cut the 8 mm rod to 12.5 mm, deburr the ends with a file. Press it into the blind hole on the right side of the cradle (the hub with the small hole on top). Lock it with the M3 × 6 screw from above. A drop of superglue is OK too.

**Step 6. Camera on the roll plate, roll plate in the cradle.** Fold the C922 clip flat under the camera. Screw the 1/4"-20 screw from below through the slot of `roll_plate` into the clip's tripod thread, only finger-tight for now (the head sits in the recess, so the curved underside stays smooth). Lay the roll plate into the curved saddle of the cradle, its back face against the cradle's rear wall. Put the M3 × 10 with a washer through the curved slot in the rear wall into the hole in the back of the roll plate, finger-tight.

How roll works: the underside of the roll plate is an arc centred on the lens axis, so rocking it in the saddle turns the camera about its own centre, ±10°. The notches on the back of the plate are every 5°. To set roll: loosen the M3, rock the camera, tighten.

**Step 7. Join cradle and uprights, without the tilt motor yet.** First press two M3 nuts into the hex pockets on the inner face of `upright_motor` (a dab of glue keeps them in; later the cradle covers them). Push the cradle's rod into the bearing of `upright_bearing`. On the other side, push an M3 screw (or a 3 mm drill bit) through the big hole of `upright_motor` into the cradle's D-hole as a temporary axle. Stand both uprights on the turntable, feet over the 4 holes, and screw M3 × 12 from **below** (heads go into the round recesses under the turntable, so they never touch the base), nuts on top of the feet. Leave ~0.3 mm side play for the cradle.

Check: the cradle must swing freely all the way round without touching anything (checked in CAD from −90° to +90° with the camera in). Pan must turn freely too.

**Step 8. Balance the camera (important, do it now while the cradle swings freely).**
The 28BYJ-48 has only ~300 g·cm of torque. A camera 1 cm off the axis already needs 160 g·cm, half the motor. Balanced, it needs almost nothing and holds position with the coils off.
1. **Front-back:** hold the cradle level and let go. If it tips forward or back, slide the camera along the roll plate's slot the other way. Repeat until it stays level, then tighten the screw.
2. **Up-down:** tilt the cradle to 45° and let go. Swings back to level: the camera is too low; falls over further: too high. Raise it with washers or a printed spacer under the clip. If it is too high, reprint the cradle with a bigger `CAM_H` (default 22 mm: from the cradle floor to the axis).
3. Good enough when it stays roughly where you leave it at any angle.

**Step 9. Tilt motor.** Remove the temporary axle. Turn the motor shaft so the flats line up with the D-hole (the flat in the cradle faces up when the cradle is level). Put the motor on the outer face: round boss in the big hole, shaft into the cradle, body **above** the shaft, blue cap pointing up. Screw the ears with M3 × 10.

**Step 10. Final check with power.** `M 0 300` then `M 0 -300`: both directions should sound the same and never click (clicking = skipped steps = not balanced or too fast). `M 600 0` / `M -600 0` for pan.

**Cables.** Tie the USB cable to the cradle with a loose loop at the axis, so the cable does not pull the camera. Leave a big slack loop for pan too.

## 5. Mount on the rig

Screw the base flange to the profile carriage (4 holes on a 70 mm square, Ø4.5 for M4). If your carriage is smaller than that, tell me the hole pattern and I'll change `FL_PITCH` or add an adapter plate. Route both motor cables along the profile with ties, leaving slack at the turntable.

The software soft limits are pan ±60° and tilt ±30° from where you start, so start roughly pointing the right way.

## 6. First run with the app

```bash
python align_camera.py --cam 0 --calib calib.json --target align_target/target.json --motors
```
1. Set position (right/up/forward) by hand on the carriages following `NEXT:`.
2. Press `A`. First time only, the app turns each motor ~8° to learn direction and steps per degree (saved to `motors.json`). So it does not matter which way you mounted the motors.
3. It then closes the loop until pan and tilt are within 0.5°, and turns the coils off.
4. Roll: by hand, last: loosen the M3 at the back of the cradle, rock the camera until the app's roll bar is green, tighten.

If you rebuild the mount, run once with `--recal-motors`.

## 7. Motorized roll (later, optional)

Roll is manual for now (roll plate). If you want it motorized later, the third motor goes on Nano pins A0–A3 with a third ULN2003 (you have spares). That needs a small change to the firmware and `motors.py`, plus a motor bracket replacing the roll plate; ask and I'll add it.

## 8. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| Motor buzzes, does not turn | IN1–IN4 order wrong, or 5 V supply too weak (needs ≥1 A) |
| Motor turns sometimes the wrong way | that's fine, the app learns direction; if it was already learned, `--recal-motors` |
| Tilt clicks / skips under load | camera not balanced (step 8), or lower `MAX_SPEED` in firmware to 500 |
| Turntable wobbles | spigot loose in the bearing: reprint the turntable with `SPIGOT_D` 0.05 bigger, or one layer of tape around the spigot |
| D-hole slips on the shaft | reprint with `D_FLAT` 0.1 smaller, or a drop of superglue |
| Motor gets hot | normal for 28BYJ-48 while holding; the app sends `R` after aligning |
| "motors: pan did not move" in app | PAN board not powered or the motor plugged into the TILT board |

## What is verified and what is not

- Verified in CAD: all 7 parts render as valid STLs, fit a 255 mm bed, no collision between cradle + roll plate + camera and the uprights/turntable/tilt motor for every combination of tilt −90°…+90° and roll −10°…+10°, and the camera never touches the cradle while rolling, nothing touches between base and turntable.
- **Not verified:** nothing has been printed yet. Motor and camera sizes are typical datasheet values (28BYJ-48 body Ø28, ears 35 mm, shaft offset 8 mm; C922 body ~94 × 29 × 24 mm). That's why the fit test and the calipers check come first.

---

## Board holder for the side-camera target (2026-10-29)

`board_holder.py` → `stl/board_holder.stl` (print on its side as exported, PETG, no supports, 178.6 mm tall) and `board_holder.png` (section).
Holds the 3D-printed ChArUco board (`../board3d/`, 170 × 230 × 4 mm) on the +x end of the tray plate: the hook rests on the plate top, the back wall leans on the end face, so the board lands at the spot from Isaac Sim (`board_placement.json`) without measuring.
- Pattern plane 7.0 mm in front of the end face (3 mm wall + 4 mm board). The first export assumed 1 mm, so the board in the twin must be moved to +7 mm and the target re-exported.
- Pattern bottom 39 mm below the plate top, centred on the tray.
- Check on the real tray: the end face is flat for ~50 mm down, and the first vial row leaves ≥ 8 mm free from the edge (`LIP`).

## Profile plate for the line mounts (2026-10-29)

`profile_plate.py` → `stl/profile_plate.stl` (90 × 90 × 10 mm + key, PETG, prints flat as exported, no supports), `profile_plate.png`.
Puts the pan-tilt head on a 4040 arm (slot 8): 2× M6 × 16 into slot-8 T-nuts (heads sunk under the flange, ±10 mm along the profile), head flange with 4× M4 × 20 + nuts in the channels underneath (±5 mm across). Same plate for SIDE (head on top of the arm) and DIAG (head hanging under the arm).
Lens centre = 83.5 mm above the flange underside + 10 mm plate = **93.5 mm above the profile face**.
The tilt cradle swings ±90° mechanically, so DIAG needs no 35° wedge: power up with the camera tilted to ~35° by hand (the ±30° motor range is around the start position).

## Printed line mounts, no profile or brackets (2026-10-29)

`line_mounts.py` → `stl/side_arm.stl`, `stl/diag_riser.stl`, `stl/diag_arm.stl`, `line_mounts.png`. All PETG, 4–5 walls, 30–40 % infill, no supports. The head screws straight onto the pad (no `profile_plate` needed). Clamping uses long M5 bolts that run behind / under the 50 × 50 portal member, so the portal slot type does not matter.

| Part | Print | Fits on the line |
|---|---|---|
| side_arm (90 × 227 × 40) | upside down as exported | collar around portal post P1, arm toward −y. Collar top **426 mm above the top of the portal foot beam** (z 1.2075). Pan axis 123 mm from the P1 −y face, centred on the post. |
| diag_riser (64 × 40 × 223) | upright as exported | saddle on the portal top beam, riser centre **49 mm from the P2 face** (y −0.259). |
| diag_arm (218 × 90 × 40) | as exported | on top of the riser, arm toward −x (over the tray side); the head hangs under the pad, pad centre 153 mm from the beam centre. |

Hardware: 4× M5 × 70 + nuts (clamps, 2 per collar/saddle), 2× M5 × 60 + nuts (arm to riser, nuts slide into the riser from −y), 8× M4 × 20 + nuts (heads onto the pads). A strip of rubber or electrical tape inside the collar helps it not slip. Heights are nominal (±5 mm): camera_align does the fine placement.
