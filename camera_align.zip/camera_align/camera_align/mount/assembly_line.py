"""Overview picture of the line mounts in place: portal, tray, SIDE and DIAG mounts, heads, cameras.
World coordinates from the mount survey (metres in the USD, millimetres here). Simple flat-shaded
painter's renderer, no OpenGL needed.

    python assembly_line.py   -> assembly_line.png
"""
import os

import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont

import line_mounts as lm

HERE = os.path.dirname(os.path.abspath(__file__))
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"


def mesh_of(manifold):
    m = manifold.to_mesh()
    return trimesh.Trimesh(vertices=np.asarray(m.vert_properties)[:, :3], faces=np.asarray(m.tri_verts))


def box(lo, hi):
    lo, hi = np.asarray(lo, float), np.asarray(hi, float)
    b = trimesh.creation.box(extents=hi - lo)
    b.apply_translation((lo + hi) / 2)
    return b


def cyl(center, r, h, sections=24):
    c = trimesh.creation.cylinder(radius=r, height=h, sections=sections)
    c.apply_translation(center)
    return c


def scene():
    items = []   # (mesh, rgb)
    alu, dark = (175, 180, 188), (70, 70, 75)
    # portal 50x50 (P1, P2, top beam, foot beams)
    for y0, y1 in ((-589.7, -539.7), (-209.7, -159.7)):
        items.append((box([102, y0, 781.3], [152, y1, 1601.3]), alu))
        items.append((box([25, y0, 731.3], [215, y1, 781.3]), alu))
    items.append((box([102, -539.7, 1543.3], [152, -209.7, 1593.3]), alu))
    # MagneMover track between the portal and the tray station (low, dark)
    items.append((box([-200, -850, 771], [100, -100, 803]), (60, 60, 65)))
    # tray plate and 30 vials (6 columns along x, 5 rows along y), approximate layout
    x_end, top = -211.4, 1225.0
    items.append((box([x_end - 345, -820, top - 6], [x_end, -495, top]), (215, 215, 215)))
    items.append((box([x_end - 345, -820, top - 60], [x_end, -495, top - 6]), (40, 40, 40)))
    for i in range(6):
        for j in range(5):
            cx, cy = x_end - 35 - i * 51.2, -780 + j * 61.2
            items.append((cyl([cx, cy, top + 23], 13, 46, 16), (205, 215, 225)))
            items.append((cyl([cx, cy, 1281.5], 22.3, 19.3, 20), (235, 215, 40)))
    # SIDE mount: collar on P1, pad top at z 1207.5
    side, _, _ = lm.side_arm()
    s = mesh_of(side)
    s.apply_translation([127, -564.7, 1207.5])
    items.append((s, (90, 140, 220)))
    pad = np.array([127, -564.7 - 25 - lm.SIDE_REACH, 1207.5])
    items.append((box(pad + [-30, -30, 0], pad + [30, 30, 50]), dark))                 # pan base
    items.append((box(pad + [-25, -72, 50], pad + [25, 72, 57]), dark))                # turntable
    for sx in (-1, 1):
        items.append((box(pad + [-8, sx * 58 - 4, 57], pad + [8, sx * 58 + 4, 120]), dark))   # uprights
    lens_s = np.array([127, -712.7, 1291.0])
    items.append((box(lens_s + [0, -47, -14], lens_s + [24, 47, 15]), (25, 25, 25)))   # C922, faces -x
    # DIAG mount: saddle on the top beam at y -259, arm toward -x, head hanging
    r0 = np.array([127, -259, 1593.3])
    for part in (lm.diag_riser()[0], lm.diag_arm()[0]):
        m = mesh_of(part)
        m.apply_translation(r0)
        items.append((m, (90, 140, 220)))
    pad_d = r0 + [-lm.DIAG_REACH, lm.DIAG_DY, lm.DIAG_H]
    items.append((box(pad_d + [-30, -30, -50], pad_d + [30, 30, 0]), dark))
    items.append((box(pad_d + [-25, -72, -57], pad_d + [25, 72, -50]), dark))
    for sx in (-1, 1):
        items.append((box(pad_d + [-8, sx * 58 - 4, -120], pad_d + [8, sx * 58 + 4, -57]), dark))
    lens_d = np.array([-26, -249, 1674.0])
    look = np.array([-375, -660, 1260.0]) - lens_d
    look /= np.linalg.norm(look)
    cam = box([-12, -47, -14], [12, 47, 15])
    yaw = np.arctan2(look[1], look[0])
    cam.apply_transform(trimesh.transformations.rotation_matrix(yaw, [0, 0, 1]))
    cam.apply_translation(lens_d)
    items.append((cam, (25, 25, 25)))
    return items, {"SIDE": (lens_s, np.array([-1.0, 0, 0])), "DIAG": (lens_d, look)}


def render(items, cams, path, eye_dir=(1.0, 0.55, 0.55), size=(1500, 1050)):
    eye = np.asarray(eye_dir, float); eye /= np.linalg.norm(eye)
    up = np.array([0, 0, 1.0])
    right = np.cross(up, eye); right /= np.linalg.norm(right)
    up2 = np.cross(eye, right)
    light = np.array([0.4, 0.3, 1.0]); light /= np.linalg.norm(light)
    tris = []
    for m, rgb in items:
        v = m.vertices
        for f, n in zip(m.faces, m.face_normals):
            if np.dot(n, eye) <= 0:
                continue
            p = v[f]
            shade = 0.45 + 0.55 * max(0.0, float(np.dot(n, light)))
            tris.append((float(np.mean(p @ eye)), p, tuple(int(c * shade) for c in rgb)))
    allp = np.vstack([t[1] for t in tris])
    u, w = allp @ right, allp @ up2
    sc = min((size[0] - 120) / (u.max() - u.min()), (size[1] - 160) / (w.max() - w.min()))
    off = np.array([60 - u.min() * sc, size[1] - 100 + w.min() * sc])

    def P(p):
        return (off[0] + np.dot(p, right) * sc, off[1] - np.dot(p, up2) * sc)

    img = Image.new("RGB", size, (250, 250, 248))
    d = ImageDraw.Draw(img)
    for _, p, col in sorted(tris, key=lambda t: t[0]):
        d.polygon([P(q) for q in p], fill=col, outline=col)
    f = ImageFont.truetype(FONT, 20)
    fs = ImageFont.truetype(FONT, 16)
    for name, (lens, look) in cams.items():
        a, b = P(lens), P(lens + look * 260)
        d.line([a, b], fill=(220, 40, 40), width=3)
        d.ellipse([b[0] - 5, b[1] - 5, b[0] + 5, b[1] + 5], fill=(220, 40, 40))
    labels = [
        (cams["SIDE"][0] + [0, -60, 40], "SIDE: C922 на высоте крышек, смотрит вдоль рядов"),
        (np.array([127, -700, 1160.0]), "side_arm: хомут на стойке P1"),
        (cams["DIAG"][0] + [0, 0, 150], "DIAG: голова висит, 35° вниз"),
        (np.array([127, -259, 1700.0]), "diag_riser + diag_arm на верхней балке"),
        (np.array([-380, -660, 1300.0]), "лоток 6×5"),
        (np.array([127, -564, 800.0]), "рама 50×50 (P1)"),
        (np.array([127, -185, 800.0]), "P2"),
        (np.array([-50, -150, 810.0]), "MagneMover"),
    ]
    for p, text in labels:
        x, y = P(p)
        d.text((x + 8, y - 10), text, font=fs, fill=(20, 20, 20), stroke_width=3, stroke_fill=(250, 250, 248))
    d.text((20, 15), "Крепление камер на раме линии (печатные детали синие, головы pan-tilt тёмные, красное = куда смотрит камера)",
           font=f, fill=(20, 20, 20))
    img.save(path)


if __name__ == "__main__":
    items, cams = scene()
    render(items, cams, os.path.join(HERE, "assembly_line.png"), eye_dir=(0.9, -1.0, 0.65))
    render(items, cams, os.path.join(HERE, "assembly_line_top.png"), eye_dir=(0.15, 0.1, 1.0))
    print("ok")
