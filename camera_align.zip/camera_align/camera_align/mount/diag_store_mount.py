"""Picture of the store-bought DIAG mount: slotted-angle riser + arm clamped to the portal top beam with two C-clamps,
angle_plate under the arm end, pan-tilt head hanging under the plate.  python diag_store_mount.py -> diag_store_mount.png"""
import os

import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont

from assembly_line import box, cyl, FONT

HERE = os.path.dirname(os.path.abspath(__file__))
LENS = np.array([-26.0, -249.0, 1674.0])
BEAM_TOP, BEAM_X0 = 1593.3, 102.0
PLATE_Z = 1757.5                      # plate underside = head flange
ARM_Z = PLATE_Z + 10                  # arm underside


def scene():
    alu, steel, blue, dark, red = (175, 180, 188), (120, 125, 135), (90, 140, 220), (60, 60, 65), (200, 50, 40)
    it = []
    it.append((box([102, -539.7, 1543.3], [152, -209.7, 1593.3]), alu))           # top beam
    it.append((box([102, -209.7, 1300], [152, -159.7, 1601.3]), alu))             # P2 (cut)
    x_end, top = -211.4, 1225.0                                                    # tray corner
    it.append((box([x_end - 345, -820, top - 6], [x_end, -495, top]), (215, 215, 215)))
    for i in range(6):
        for j in range(5):
            cx, cy = x_end - 35 - i * 51.2, -780 + j * 61.2
            it.append((cyl([cx, cy, top + 23], 13, 46, 16), (205, 215, 225)))
            it.append((cyl([cx, cy, 1281.5], 22.3, 19.3, 20), (235, 215, 40)))
    y0, y1, t, w = -265.0, -233.0, 2.0, 32.0
    # riser: flat leg against the beam's tray-side face, second leg toward the tray
    it.append((box([BEAM_X0 - t, y0, 1543.3], [BEAM_X0, y1, ARM_Z + w]), steel))
    it.append((box([BEAM_X0 - w, y0, 1543.3], [BEAM_X0, y0 + t, ARM_Z + w]), steel))
    # arm: horizontal leg (plate bolts under it) + vertical leg, from the riser toward the tray
    it.append((box([-98, y0, ARM_Z], [BEAM_X0 - t, y1, ARM_Z + t]), steel))
    it.append((box([-98, y0, ARM_Z], [BEAM_X0 - t, y0 + t, ARM_Z + w]), steel))
    # angle_plate (printed) and the hanging head
    c = np.array([LENS[0], LENS[1], PLATE_Z])
    it.append((box(c + [-45, -45, 0], c + [45, 45, 10]), blue))
    it.append((box(c + [-30, -30, -50], c + [30, 30, 0]), dark))                    # pan base
    it.append((box(c + [-25, -72, -57], c + [25, 72, -50]), dark))                  # turntable
    for s in (-1, 1):
        it.append((box(c + [-8, s * 58 - 4, -120], c + [8, s * 58 + 4, -57]), dark))
    look = np.array([-375, -660, 1260.0]) - LENS
    look /= np.linalg.norm(look)
    cam = box([-12, -47, -14], [12, 47, 15])
    cam.apply_transform(trimesh.transformations.rotation_matrix(np.arctan2(look[1], look[0]), [0, 0, 1]))
    cam.apply_translation(LENS)
    it.append((cam, (25, 25, 25)))
    # two C-clamps across the beam (x), frame loops under the beam
    for yc in (-259.0, -239.0):
        it.append((box([BEAM_X0 - 14, yc - 5, 1560], [BEAM_X0 - t, yc + 5, 1580]), red))   # jaw on the angle
        it.append((box([152, yc - 5, 1560], [164, yc + 5, 1580]), red))                   # jaw on the far face
        it.append((box([BEAM_X0 - 24, yc - 4, 1500], [BEAM_X0 - 14, yc + 4, 1580]), red))
        it.append((box([164, yc - 4, 1500], [174, yc + 4, 1580]), red))
        it.append((box([BEAM_X0 - 24, yc - 4, 1490], [174, yc + 4, 1500]), red))
    return it, look


def render(items, look, labels, path, eye_dir, size=(1400, 1000), title=""):
    eye = np.asarray(eye_dir, float); eye /= np.linalg.norm(eye)
    up = np.array([0, 0, 1.0])
    right = np.cross(up, eye); right /= np.linalg.norm(right)
    up2 = np.cross(eye, right)
    light = np.array([0.4, 0.3, 1.0]); light /= np.linalg.norm(light)
    tris = []
    for m, rgb in items:
        for f, n in zip(m.faces, m.face_normals):
            if np.dot(n, eye) <= 0:
                continue
            p = m.vertices[f]
            sh = 0.45 + 0.55 * max(0.0, float(np.dot(n, light)))
            tris.append((float(np.mean(p @ eye)), p, tuple(int(v * sh) for v in rgb)))
    allp = np.vstack([t[1] for t in tris])
    u, w = allp @ right, allp @ up2
    sc = min((size[0] - 420) / (u.max() - u.min()), (size[1] - 140) / (w.max() - w.min()))
    off = np.array([60 - u.min() * sc, size[1] - 60 + w.min() * sc])
    P = lambda p: (off[0] + np.dot(p, right) * sc, off[1] - np.dot(p, up2) * sc)
    img = Image.new("RGB", size, (250, 250, 248))
    d = ImageDraw.Draw(img)
    for _, p, col in sorted(tris, key=lambda t: t[0]):
        d.polygon([P(q) for q in p], fill=col, outline=col)
    a, b = P(LENS), P(LENS + look * 220)
    d.line([a, b], fill=(220, 40, 40), width=3)
    fs = ImageFont.truetype(FONT, 17)
    for p, text in labels:
        x, y = P(np.asarray(p, float))
        d.line([(x, y), (size[0] - 350, y)], fill=(150, 150, 150), width=1)
        d.text((size[0] - 345, y - 10), text, font=fs, fill=(20, 20, 20))
    d.text((20, 12), title, font=ImageFont.truetype(FONT, 20), fill=(20, 20, 20))
    return img


if __name__ == "__main__":
    items, look = scene()
    labels = [
        ((-60, -249, ARM_Z + 16), "рука: уголок 20 см, к лотку"),
        ((BEAM_X0 - 1, -249, 1625), "стойка: уголок 25 см"),
        ((LENS[0], -249, PLATE_Z + 5), "angle_plate (печать), 2× 1/4-20"),
        ((LENS[0], -249, PLATE_Z - 30), "голова pan-tilt, 4× M4×20"),
        (LENS, "C922: объектив ~8 см выше балки"),
        ((168, -249, 1495), "2 струбцины Husky 4 in"),
        ((127, -400, 1570), "верхняя балка рамы 50×50"),
        ((127, -185, 1400), "стойка P2"),
        ((-380, -660, 1300), "лоток (G26–G30 ближе к раме)"),
    ]
    a = render(items, look, labels, None, (0.9, -1.0, 0.55), title="DIAG: вид сбоку-спереди")
    b = render(items, look, labels[:6], None, (0.0, -1.0, 0.0001), title="DIAG: вид вдоль балки (красная линия = куда смотрит камера)")
    out = Image.new("RGB", (1400, 2000), (250, 250, 248))
    out.paste(a, (0, 0)); out.paste(b, (0, 1000))
    out.save(os.path.join(HERE, "diag_store_mount.png"))
    print("ok")
