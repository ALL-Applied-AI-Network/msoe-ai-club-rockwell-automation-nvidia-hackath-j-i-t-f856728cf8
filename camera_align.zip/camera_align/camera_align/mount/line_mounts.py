"""Printed line mounts for the SIDE and DIAG cameras: no aluminium profile, no brackets, no T-nuts.
Both clamp onto the existing 50 x 50 portal from the mount survey (mount_plan.json, 2026-10-29) with long
M5 bolts that pass BEHIND / UNDER the frame member, so the slot type of the portal does not matter.

    python line_mounts.py  -> stl/side_arm.stl, stl/diag_riser.stl, stl/diag_arm.stl, line_mounts.png

SIDE  lens (0.127, -0.713, 1.291): a collar around portal post P1 (x 0.102-0.152, y -0.590..-0.540) with an arm
      in -y; the head stands on the pad at the arm end. Pad top (= arm and collar top) at z 1.2075.
DIAG  lens (-0.026, -0.249, 1.674): a saddle on the portal top beam (top z 1.5933, x 0.102-0.152) at y -0.259,
      a riser, and an arm in -x; the head hangs under the pad. Pad underside at z 1.7575.
Head: lens centre 83.5 mm from the underside of the pan base flange (pantilt_mount.scad: 31.5 + 52);
flange 84 x 84 with 4x M4 on a 70 mm square. Pads have M4 slots +-5 mm and nut channels.
"""
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

POST = 50.0          # portal member section
FIT = 0.2            # gap to the aluminium per side
LENS_ABOVE_FLANGE = 83.5
PAD, PAD_T = 90.0, 10.0
FL_PITCH, M4_W, M4_HALF, NUT4_AF, NUT4_D = 70.0, 4.6, 5.0, 7.4, 3.6
M5_D, NUT5_AF, NUT5_T = 5.5, 8.3, 4.4
QUARTER_D = 6.8      # 1/4-20 clearance through the SIDE pad + arm (ball head instead of the pan-tilt head)
ARM = 40.0           # arm / riser section
WALL = 7.0           # clamp walls

# SIDE: pan axis 123 mm in -y from the P1 -y face (0.713 - 0.590)
SIDE_REACH = 123.0
# DIAG: pad centre 153 mm in -x from the beam centre (0.127 + 0.026), +10 mm in y from the riser centre,
# pad underside 164 mm above the beam top (1.7575 - 1.5933)
DIAG_REACH, DIAG_DY, DIAG_H = 153.0, 10.0, 164.0
BASE_T = 6.0


def box(lo, hi):
    import manifold3d as m3d
    lo, hi = np.asarray(lo, float), np.asarray(hi, float)
    return m3d.Manifold.cube(list(hi - lo)).translate(list(lo))


def cyl(p, axis, d, length, seg=32):
    """Cylinder centred on point p along axis 'x' | 'y' | 'z'."""
    import manifold3d as m3d
    c = m3d.Manifold.cylinder(length, d / 2, d / 2, seg).translate([0, 0, -length / 2])
    if axis == "x":
        c = c.rotate([0, 90, 0])
    elif axis == "y":
        c = c.rotate([90, 0, 0])
    return c.translate(list(p))


def hexpocket(p, axis, af, t):
    return cyl(p, axis, af / np.cos(np.pi / 6), t, seg=6)


def stadium_z(cx, cy, half, w, z0, z1):
    import manifold3d as m3d
    r = w / 2
    s = (m3d.CrossSection.circle(r, 32).translate((cx - half, cy)) + m3d.CrossSection.circle(r, 32).translate((cx + half, cy))
         + m3d.CrossSection.square((2 * half, w), center=True).translate((cx, cy)))
    return m3d.Manifold.extrude(s, z1 - z0).translate([0, 0, z0])


def flange_cuts(cx, cy, z0, z1, nut_side):
    """4 M4 slots (+-5 mm in x) through the pad, hex-nut channels on the face away from the head."""
    cuts = []
    h = FL_PITCH / 2
    for sx in (-1, 1):
        for sy in (-1, 1):
            x, y = cx + sx * h, cy + sy * h
            cuts.append(stadium_z(x, y, M4_HALF, M4_W, z0 - 1, z1 + 1))
            if nut_side == "bottom":
                cuts.append(stadium_z(x, y, M4_HALF, NUT4_AF, z0 - 1, z0 + NUT4_D))
            else:
                cuts.append(stadium_z(x, y, M4_HALF, NUT4_AF, z1 - NUT4_D, z1 + 1))
    return cuts


def side_arm():
    """Local frame: P1 centred at x = y = 0, z = 0 at the top (pad top = arm top = collar top)."""
    a = POST / 2 + FIT
    collar_back = a + 2.7 + 6          # bolts pass 0.5 mm behind the post's +y face
    front = -a - WALL
    pad_c = -POST / 2 - SIDE_REACH
    solid = box([-a - WALL, front, -ARM], [a + WALL, collar_back, 0])                  # collar block
    solid = solid + box([-ARM / 2, pad_c, -ARM], [ARM / 2, front + 1, 0])            # arm
    solid = solid + box([-PAD / 2, pad_c - PAD / 2, -PAD_T], [PAD / 2, pad_c + PAD / 2, 0])   # head pad
    cuts = [box([-a, -a, -ARM - 1], [a, collar_back + 1, 1])]                           # post + open back
    for z in (-10.0, -30.0):
        bolt = (0, a + 2.7, z)
        cuts.append(cyl(bolt, "x", M5_D, 2 * (a + WALL) + 2))
    cuts += flange_cuts(0, pad_c, -PAD_T, 0, nut_side="bottom")
    cuts.append(cyl((0, pad_c, -ARM / 2), "z", QUARTER_D, ARM + 2))                   # 1/4-20 bolt for a ball head
    for c in cuts:
        solid = solid - c
    # bolts behind the post need a bridge: keep the back corners as two cheeks
    return solid, "print upside down (pad and collar top on the bed)", np.pi


def diag_riser():
    """Local frame: beam top centre under the riser at the origin, beam along y, riser up +z."""
    a = POST / 2 + FIT
    depth = ARM
    walls_bottom = -POST - 2.7 - 6
    solid = box([-a - WALL, -depth / 2, walls_bottom], [a + WALL, depth / 2, BASE_T])     # saddle
    solid = solid + box([-ARM / 2, -ARM / 2, BASE_T], [ARM / 2, ARM / 2, DIAG_H])       # riser
    cuts = [box([-a, -depth / 2 - 1, walls_bottom - 1], [a, depth / 2 + 1, 0])]           # the beam
    for y in (-10.0, 10.0):
        cuts.append(cyl((0, y, -POST - FIT - 2.7), "x", M5_D, 2 * (a + WALL) + 2))      # bolts under the beam
    for x in (-10.0, 10.0):                                                              # arm bolts, nuts from -y
        cuts.append(cyl((x, 0, DIAG_H - 12), "z", M5_D, 26))
        cuts.append(box([x - NUT5_AF / 2, -ARM / 2 - 1, DIAG_H - 17 - NUT5_T / 2], [x + NUT5_AF / 2, 0 + NUT5_AF / 2,
                                                                                         DIAG_H - 17 + NUT5_T / 2]))
    for c in cuts:
        solid = solid - c
    return solid, "print upright (saddle walls on the bed)", 0.0


def diag_arm():
    """Same frame as the riser. Arm from the riser outer face to the pad; the pad underside is the arm underside."""
    z0, z1 = DIAG_H, DIAG_H + ARM
    pad_cx, pad_cy = -DIAG_REACH, DIAG_DY
    solid = box([pad_cx - PAD / 2, -ARM / 2, z0], [ARM / 2, ARM / 2, z1])
    solid = solid + box([pad_cx - PAD / 2, pad_cy - PAD / 2, z0], [pad_cx + PAD / 2, pad_cy + PAD / 2, z0 + PAD_T])
    cuts = []
    for x in (-10.0, 10.0):
        cuts.append(cyl((x, 0, (z0 + z1) / 2), "z", M5_D, ARM + 2))
        cuts.append(cyl((x, 0, z1 - 2.5), "z", 9.5, 5.1))                              # bolt head seat
    cuts += flange_cuts(pad_cx, pad_cy, z0, z0 + PAD_T, nut_side="top")
    for c in cuts:
        solid = solid - c
    return solid, "print as exported (pad underside on the bed)", 0.0


def export(solid, flip, path):
    import trimesh
    mesh = solid.to_mesh()
    tm = trimesh.Trimesh(vertices=np.asarray(mesh.vert_properties)[:, :3], faces=np.asarray(mesh.tri_verts))
    if flip:
        tm.apply_transform(trimesh.transformations.rotation_matrix(flip, [1, 0, 0]))
    tm.apply_translation(-tm.bounds[0])
    assert tm.is_watertight, path
    tm.export(path)
    return tm


def drawing(parts, path):
    """Three silhouettes (top / front / side) per part from the meshes, for a quick visual check."""
    from PIL import Image, ImageDraw, ImageFont
    import trimesh
    f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 15)
    img = Image.new("RGB", (1500, 300 * len(parts) + 20), "white")
    d = ImageDraw.Draw(img)
    for row, (name, tm, note) in enumerate(parts):
        y0 = 20 + row * 300
        d.text((10, y0), f"{name}: {np.round(tm.extents, 1)} mm, {note}", font=f, fill="black")
        for col, (ax, lab) in enumerate([((0, 1), "top (x,y)"), ((0, 2), "front (x,z)"), ((1, 2), "side (y,z)")]):
            s = 0.95
            ox, oy = 30 + col * 490, y0 + 260
            for tri in tm.triangles:
                p = [(ox + v[ax[0]] * s, oy - v[ax[1]] * s) for v in tri]
                d.polygon(p, fill=(150, 180, 220))
            d.text((ox, y0 + 265), lab, font=f, fill="gray")
    img.save(path)


if __name__ == "__main__":
    os.makedirs(os.path.join(HERE, "stl"), exist_ok=True)
    out = []
    for name, fn in [("side_arm", side_arm), ("diag_riser", diag_riser), ("diag_arm", diag_arm)]:
        solid, note, flip = fn()
        tm = export(solid, flip, os.path.join(HERE, "stl", f"{name}.stl"))
        out.append((name, tm, note))
        print(f"{name}: {np.round(tm.extents, 1)} mm, {note}")
    drawing(out, os.path.join(HERE, "line_mounts.png"))
