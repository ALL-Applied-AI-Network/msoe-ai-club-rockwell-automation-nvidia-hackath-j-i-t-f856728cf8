// Pan/tilt mount for Logitech C922 on 2x 28BYJ-48 (firmware/pantilt/pantilt.ino).
// Units: mm. Pan axis = Z through the origin, tilt axis = X at height ZA, camera looks along +Y.
//
// Export one part at a time (already turned for printing, no supports needed):
//   openscad -D 'part="pan_base"' -o pan_base.stl pantilt_mount.scad
// parts: fit_test, d_test, cam_screw, tilt_pin, tray, pan_base, turntable, upright_motor, upright_bearing, cradle, roll_plate, all (assembly view)
//
// Print fit_test FIRST (10 min) and tune the FIT values below before printing the rest.

part = "all";
$fn = 72;

// ---------------------------------------------------------------- fits (tune with fit_test)
BRG_POCKET = 22.15;   // 608ZZ outer 22: bearing must press in by thumb, not fall out
ROD_HOLE   = 7.9;     // 8 mm steel rod in the cradle: tight press
SPIGOT_D   = 7.95;    // printed turntable spigot in the 608 bore (8): snug, no wobble
D_ROUND    = 5.10;    // motor shaft 5 mm ...  (5.25/3.2 was loose on Simon's first fit test)
D_FLAT     = 3.05;    // ... with flats 3 mm across: snug, no wobble
SCREW_TAP  = 2.7;     // M3 screw cuts its own thread in PETG
SCREW_FREE = 3.4;     // M3 passes freely
NUT_M3     = 6.4;     // M3 nut across corners + clearance

// ---------------------------------------------------------------- 28BYJ-48 (measure yours)
M_D = 28.2;  M_H = 19.5;          // body
M_EAR = 35;                       // ear hole pitch
M_OFF = 8;                        // shaft offset from body centre (cap is on the far side)
M_BOSS = 9.4;  M_BOSS_H = 1.6;    // round boss around the shaft
M_SHAFT = 10;                     // shaft length from mounting face, boss included

// ---------------------------------------------------------------- camera
CAM_W = 100;     // inner width between cradle cheeks (C922 body ~94 wide, +room to roll +-10 deg)
CAM_H = 22;      // cradle floor -> tilt axis. Set to: clip foot bottom -> middle of camera body
CRADLE_D = 40;   // cradle floor depth (front-back)

// ---------------------------------------------------------------- manual roll (camera sits on a rocker)
// The roll plate's underside is an arc centred on the lens axis, it rocks in a matching saddle,
// so rolling turns the camera about its own centre. Locked by one M3 through an arc slot at the back.
ROLL_R = 32;         // rocker radius = distance from the roll axis to the rocker underside
ROLL_W = 20;         // half width of the roll plate
ROLL_D = 30;         // roll plate depth (front-back)
ROLL_MAX = 10;       // +- roll range, deg
ROLL_SCREW_R = 25;   // lock screw distance below the axis
ZF = -(ROLL_R + 4);  // cradle floor underside

// ---------------------------------------------------------------- layout
T_TOP = M_SHAFT;          // pan base roof thickness: pan shaft tip ends flush with the roof top
BASE = 60;                // pan base outer square
WALL = 3;
BASE_H = T_TOP + M_H + 2; // roof top (z=0) down to the mounting face
FLANGE = 84; FL_HOLE = 4.5; FL_PITCH = 70; FL_T = 4;

GAP = 0.5;                // turntable floats 0.5 above the base on the bearing inner race
TT_T = 6; TT_L = 144; TT_W = 50;
TT_TOP = GAP + TT_T;      // 6.5
ZA = 52;                  // tilt axis height (cradle swings +-90 deg with ~5 mm to spare)

CHEEK = 4;                // cradle cheek thickness
XC = CAM_W/2 + CHEEK;     // 54: cradle outer face
XU = XC + 1.5;            // 55.5: upright inner face (1 mm hub + 0.5 gap)
UM_T = 5;                 // motor upright thickness
UB_T = 8;                 // bearing upright: 7 mm bearing + 1 mm lip
U_W = 46; U_TOP = ZA + 15; FOOT_T = 5; FOOT_X = 72;
FOOT_HOLE_X = 67.5; FOOT_HOLE_Y = 15;
ROD_L = XU + UB_T - (CAM_W/2 + 1);   // 12.5: tilt axle, 8 mm steel rod cut to this length

// ================================================================ helpers
module dhole(h, dr = D_ROUND, df = D_FLAT) {   // D-shaped hole along +Z, flat faces +Y
    intersection() {
        cylinder(d = dr, h = h);
        translate([-dr/2, -dr/2, 0]) cube([dr, dr/2 + df/2, h]);
    }
}
module rbox(x, y, z, r = 4) {   // box centred in XY, rounded vertical edges
    linear_extrude(z) offset(r) square([x - 2*r, y - 2*r], center = true);
}
module nut_trap(depth) { cylinder(d = NUT_M3, h = depth, $fn = 6); }

// ================================================================ fit test
module fit_test() {
    difference() {
        translate([-5, -14, 0]) cube([62, 28, 8]);
        translate([10, 0, 1]) cylinder(d = BRG_POCKET, h = 8);
        translate([10, 0, -1]) cylinder(d = 12, h = 3);
        translate([30, 0, -1]) cylinder(d = ROD_HOLE, h = 10);
        translate([42, 0, -1]) dhole(10);
        translate([51, 6, -1]) cylinder(d = SCREW_TAP, h = 10);
        translate([51, -6, -1]) cylinder(d = SCREW_FREE, h = 10);
    }
}

// ================================================================ D-hole test: 1, 2, 3 dots = tighter and tighter
D_TEST = [[5.15, 3.10], [5.10, 3.05], [5.05, 3.00]];
module d_test() {
    difference() {
        translate([-6, -7, 0]) cube([36, 14, 8]);
        for (i = [0 : 2]) {
            translate([i*12, -1.5, -1]) dhole(10, D_TEST[i][0], D_TEST[i][1]);
            for (k = [0 : i]) translate([i*12 - i*1.5 + k*3, 4.8, 7.4]) cylinder(d = 1.6, h = 1, $fn = 16);
        }
    }
}

// ================================================================ printed 1/4"-20 camera screw (if no metal one)
// Single-start helix made by twisting an off-centre circle: rounded thread, right-handed, 1.27 mm pitch.
CS_MAJOR = 6.2;      // 1/4" = 6.35, a bit under for a printed thread
CS_LEN = 10;         // 5.5 mm through the roll plate + ~4.5 mm into the camera clip
module cam_screw() {
    e = 0.35;
    cylinder(d = 11, h = 4, $fn = 30);                                    // head, fits the 12.5 plate recess
    for (a = [0 : 30 : 330]) rotate(a) translate([5.3, 0, 0]) cylinder(d = 1.2, h = 4, $fn = 12);  // grip
    translate([0, 0, 4 - 0.01]) intersection() {
        linear_extrude(CS_LEN, twist = -360 * CS_LEN / 1.27, slices = 200)
            translate([e, 0]) circle(d = CS_MAJOR - 2*e, $fn = 48);
        cylinder(d1 = CS_MAJOR + 2, d2 = CS_MAJOR - 1.2, h = CS_LEN);   // chamfered tip
    }
}

// ================================================================ printed tilt axle (if no 8 mm steel rod)
// Print standing up (round, strong along its length), 100 % infill. Same length as the steel rod.
module tilt_pin() {
    d = SPIGOT_D;   // same snug fit in the 608 bore as the turntable spigot
    difference() {
        hull() {
            cylinder(d = d - 0.8, h = 0.4);
            translate([0, 0, 0.4]) cylinder(d = d, h = ROD_L - 0.8);
            translate([0, 0, ROD_L - 0.4]) cylinder(d = d - 0.8, h = 0.4);
        }
        translate([0, 0, -1]) cylinder(d = 2, h = ROD_L + 2, $fn = 16);   // glue/air escape, less stress
    }
}

// ================================================================ electronics tray: 2x ULN2003 + Arduino Nano
// MEASURE before printing: hole spacing of the ULN2003 board (centre to centre) and the Nano PCB length.
ULN_HX = 23;     // ULN2003 holes centre to centre, along the IN1..IN7 header (board 32 x 34, holes ~2 mm)
ULN_HY = 26;     // ULN2003 holes centre to centre, across
NANO_L = 43.5;   // Nano PCB length without the USB plug sticking out
NANO_H = 24;     // Nano sits this high: Dupont plugs go on its pins from below
TRAY_X = 150; TRAY_Y = 62;
module uln_pegs() {   // board drops onto 4 pins; secure with a dab of hot glue or melt the pin tip
    for (sx = [-1, 1], sy = [-1, 1]) translate([sx*ULN_HX/2, sy*ULN_HY/2, 0]) {
        cylinder(d = 6, h = 5);
        cylinder(d = 1.7, h = 5 + 3, $fn = 20);
    }
}
module nano_posts() {   // PCB rests on two ledges (between the pin rows), one cable tie holds it down
    for (sy = [-1, 1]) mirror([0, sy < 0 ? 1 : 0, 0]) {
        translate([-5, NANO_L/2 - 2, 0]) cube([10, 6, NANO_H]);
        translate([-5, NANO_L/2 + 0.4, 0]) cube([10, 3.6, NANO_H + 4]);
    }
}
module uln_test() {   // 5-minute print: one set of pegs to check the ULN2003 hole spacing before the tray
    difference() {
        rbox(ULN_HX + 10, ULN_HY + 10, 2, 3);
        translate([0, 0, -1]) rbox(ULN_HX - 8, ULN_HY - 8, 4, 3);
    }
    translate([0, 0, 2 - 0.01]) uln_pegs();
}
module tray() {
    difference() {
        union() {
            rbox(TRAY_X, TRAY_Y, 3, 5);
            for (x = [-45, -5]) translate([x, 0, 3 - 0.01]) uln_pegs();
            translate([42, 0, 3 - 0.01]) nano_posts();
        }
        for (sx = [-1, 1]) translate([42 + sx*12 - 1.5, -2.5, -1]) cube([3, 5, 5]);   // cable tie under the Nano
        for (x = [-45, -5]) translate([x, 0, -1]) rbox(14, 16, 5, 3);              // lighten under boards
        for (x = [-TRAY_X/2 + 6, TRAY_X/2 - 6]) hull() for (y = [-8, 8])          // M4 slots to fix the tray
            translate([x, y, -1]) cylinder(d = 4.5, h = 5);
    }
}

// ================================================================ pan base (motor hangs under the roof)
module pan_base() {
    zb = -BASE_H;
    difference() {
        union() {
            translate([0, 0, zb]) rbox(BASE, BASE, BASE_H);
            // flange with a 45 deg top so the part prints upside down without supports
            hull() {
                translate([0, 0, zb]) rbox(FLANGE, FLANGE, FL_T, 6);
                translate([0, 0, zb]) rbox(BASE, BASE, FL_T + (FLANGE - BASE)/2);
            }
        }
        // cavity for the motor
        translate([0, 0, zb - 1]) rbox(BASE - 2*WALL, BASE - 2*WALL, BASE_H - T_TOP + 1, 2);
        // bearing pocket (lead-in chamfer against elephant foot) + through hole for boss/shaft
        translate([0, 0, -7]) cylinder(d = BRG_POCKET, h = 8);
        translate([0, 0, -0.6]) cylinder(d1 = BRG_POCKET, d2 = BRG_POCKET + 1.4, h = 0.61);
        translate([0, 0, -T_TOP - 1]) cylinder(d = 12, h = T_TOP);
        // motor ear screws, blind from below
        for (s = [-1, 1]) translate([s*M_EAR/2, -M_OFF, -T_TOP - 1]) cylinder(d = SCREW_TAP, h = 9);
        // wire slot on the -Y side (motor cap side)
        translate([-10, -BASE, zb - 1]) cube([20, BASE, 15]);
        // flange holes
        for (sx = [-1, 1], sy = [-1, 1])
            translate([sx*FL_PITCH/2, sy*FL_PITCH/2, zb - 1]) cylinder(d = FL_HOLE, h = 40);
    }
}

// ================================================================ turntable (rides on the pan bearing)
module turntable() {
    difference() {
        union() {
            translate([0, 0, GAP]) rbox(TT_L, TT_W, TT_T, 6);
            translate([0, 0, -8]) cylinder(d = SPIGOT_D, h = 8 + GAP + 0.01);  // spigot in bearing
            cylinder(d = 11, h = GAP + 0.01);                               // touches inner race only
        }
        translate([0, 0, -8.01]) rotate([0, 0, 90]) dhole(9.5);             // pan motor shaft
        for (sx = [-1, 1], sy = [-1, 1]) translate([sx*FOOT_HOLE_X, sy*FOOT_HOLE_Y, 0]) {
            cylinder(d = SCREW_FREE, h = 20);
            translate([0, 0, GAP - 0.01]) cylinder(d = 6.5, h = 3.2);       // head recess underneath
        }
        // cable-tie slots for the tilt motor wires
        for (sx = [-1, 1]) translate([sx*30 - 2, TT_W/2 - 10, 0]) cube([4, 6, 20]);
        // lighten
        for (sx = [-1, 1]) translate([sx*30, -6, GAP - 1]) rbox(24, 22, 10, 5);
    }
}

// ================================================================ uprights (shown on the -X / +X side)
module upright_body(t) {   // plate from x=0 (inner face) to x=t, foot outward to FOOT_X - XU
    fl = FOOT_X - XU;
    translate([0, -U_W/2, TT_TOP]) cube([t, U_W, U_TOP - TT_TOP - 5]);
    hull() for (y = [-U_W/2 + 5, U_W/2 - 5]) translate([0, y, U_TOP - 5]) rotate([0, 90, 0]) cylinder(r = 5, h = t);
    translate([0, -U_W/2, TT_TOP]) cube([fl, U_W, FOOT_T]);
    for (y = [-U_W/2, U_W/2 - 3]) translate([t, y, TT_TOP + FOOT_T])          // gussets
        rotate([90, 0, 0]) translate([0, 0, -3]) linear_extrude(3) polygon([[0, 0], [fl - t - 1, 0], [0, 14]]);
}
module foot_holes() {
    for (y = [-FOOT_HOLE_Y, FOOT_HOLE_Y]) translate([FOOT_HOLE_X - XU, y, 0]) cylinder(d = SCREW_FREE, h = 40);
}

module upright_motor() {   // local: x=0 inner face, motor bolts to the outer face x=UM_T
    difference() {
        upright_body(UM_T);
        translate([-1, 0, ZA]) rotate([0, 90, 0]) cylinder(d = 10, h = UM_T + 2);        // boss + shaft
        for (y = [-M_EAR/2, M_EAR/2]) translate([-1, y, ZA + M_OFF]) rotate([0, 90, 0]) {
            cylinder(d = SCREW_FREE, h = UM_T + 2);
            translate([0, 0, 0.99]) rotate([0, 0, 30]) nut_trap(2.6);                     // nut on inner face
        }
        foot_holes();
    }
}

module upright_bearing() {   // local: x=0 inner face, bearing pressed in from the outer face
    difference() {
        upright_body(UB_T);
        translate([1, 0, ZA]) rotate([0, 90, 0]) cylinder(d = BRG_POCKET, h = UB_T);
        translate([-1, 0, ZA]) rotate([0, 90, 0]) cylinder(d = 12, h = UB_T);
        foot_holes();
    }
}

// ================================================================ camera cradle (local: tilt axis = X through origin)
module cradle() {
    yb = -CRADLE_D/2;
    difference() {
        union() {
            translate([-XC, yb, ZF]) cube([2*XC, CRADLE_D, 4]);                         // floor
            translate([-ROLL_W + 1, yb + 3, ZF + 3]) cube([2*ROLL_W - 2, CRADLE_D - 3, 6]); // saddle block
            translate([-ROLL_W - 2, yb, ZF + 3]) cube([2*ROLL_W + 4, 3, -CAM_H - 0.5 - ZF - 3]); // rear wall
            for (sx = [-1, 1]) translate([sx > 0 ? CAM_W/2 : -XC, 0, 0])               // cheeks
                hull() {
                    rotate([0, 90, 0]) cylinder(r = 9, h = CHEEK);
                    translate([0, yb, ZF]) cube([CHEEK, CRADLE_D, 4]);
                }
            translate([-XC - 1, 0, 0]) rotate([0, 90, 0]) cylinder(d = 14, h = 1 + CHEEK);   // motor hub
            translate([CAM_W/2, 0, 0]) rotate([0, 90, 0]) cylinder(d = 16, h = CHEEK + 1);   // rod hub
            translate([XC + 1 - 0.01, 0, 0]) rotate([0, 90, 0]) cylinder(d = 11, h = 1.5);   // touches inner race
        }
        // saddle: concave arc the roll plate rocks in
        translate([0, yb + 2.99, 0]) rotate([-90, 0, 0]) cylinder(r = ROLL_R + 0.3, h = CRADLE_D, $fn = 180);
        // arc slot for the roll lock screw
        for (a = [-ROLL_MAX - 2 : 1 : ROLL_MAX + 1]) hull() for (b = [a, a + 1])
            translate([ROLL_SCREW_R*sin(b), yb - 1, -ROLL_SCREW_R*cos(b)]) rotate([-90, 0, 0]) cylinder(d = SCREW_FREE, h = 5, $fn = 24);
        // motor shaft D-hole, flat on top so it bridges cleanly when printed floor-down
        translate([-XC - 1.01, 0, 0]) rotate([0, 90, 0]) rotate([0, 0, 90]) dhole(CHEEK + 1.5);
        // 8 mm rod (blind, 1 mm wall to the camera side), plus M3 grub screw from above
        translate([CAM_W/2 + 1, 0, 0]) rotate([0, 90, 0]) cylinder(d = ROD_HOLE, h = 20);
        translate([CAM_W/2 + (CHEEK + 1)/2, 0, 0]) cylinder(d = SCREW_TAP, h = 10);
        // lighten floor
        for (sx = [-1, 1]) translate([sx*(CAM_W/2 + ROLL_W + 2)/2, 0, ZF - 1]) rbox(CAM_W/2 - ROLL_W - 8, CRADLE_D - 12, 6, 4);
    }
}

// ================================================================ roll plate (local: same frame as cradle, roll 0)
module roll_plate() {
    y0 = -CRADLE_D/2 + 3;    // rests against the rear wall
    difference() {
        intersection() {
            translate([0, y0, 0]) rotate([-90, 0, 0]) cylinder(r = ROLL_R, h = ROLL_D, $fn = 180);
            translate([-ROLL_W, y0, -ROLL_R - 1]) cube([2*ROLL_W, ROLL_D, ROLL_R + 1 - CAM_H]);
        }
        // 1/4"-20 slot (camera front/back for balance), head recessed from below
        hull() for (y = [-6, 6]) translate([0, y, -ROLL_R - 1]) cylinder(d = 6.8, h = 20);
        hull() for (y = [-6, 6]) translate([0, y, -ROLL_R - 1]) cylinder(d = 12.5, h = ROLL_R + 1 - CAM_H - 5.5);
        // lock screw from the back (M3 x 10 with washer)
        translate([0, y0 - 1, -ROLL_SCREW_R]) rotate([-90, 0, 0]) cylinder(d = SCREW_TAP, h = 13);
        // roll scale: a notch every 5 deg on the back face, read against the slot
        for (a = [-ROLL_MAX : 5 : ROLL_MAX]) translate([0, y0, 0]) rotate([0, a, 0])
            translate([-0.4, -0.01, -CAM_H - 3]) cube([0.8, 0.6, 3.01]);
    }
}

// ================================================================ placement
module camera() {   // C922 body + folded clip foot (approximate)
    translate([-47, -12, -CAM_H + 8]) cube([94, 24, 29]);
    translate([-25, -12, -CAM_H]) cube([50, 24, 8]);
}
module assembled(angle_pan = 0, angle_tilt = 0, angle_roll = 0) {
    color("SteelBlue") pan_base();
    color("Gold", 0.8) translate([0, -M_OFF, -T_TOP - M_H]) cylinder(d = M_D, h = M_H);   // pan motor
    rotate([0, 0, angle_pan]) {
        color("Orange") turntable();
        color("Tomato") translate([-XU, 0, 0]) mirror([1, 0, 0]) upright_motor();
        color("Tomato") translate([XU, 0, 0]) upright_bearing();
        color("Gold", 0.8) translate([-XU - UM_T, 0, ZA + M_OFF]) rotate([0, -90, 0]) cylinder(d = M_D, h = M_H);
        translate([0, 0, ZA]) rotate([angle_tilt, 0, 0]) {
            color("MediumSeaGreen") cradle();
            rotate([0, angle_roll, 0]) {
                color("Orchid") roll_plate();
                color("DimGray", 0.6) camera();
            }
            color("Silver") translate([CAM_W/2 + 1, 0, 0]) rotate([0, 90, 0]) cylinder(d = 8, h = ROD_L); // rod
        }
    }
}

if (part == "all")             assembled(25, -20, 8);
else if (part == "fit_test")   fit_test();
else if (part == "d_test")     d_test();
else if (part == "cam_screw")  cam_screw();
else if (part == "tilt_pin")   tilt_pin();
else if (part == "tray")       tray();
else if (part == "uln_test")   uln_test();
else if (part == "pan_base")   rotate([180, 0, 0]) pan_base();                      // roof on the bed
else if (part == "turntable")  rotate([180, 0, 0]) translate([0, 0, -TT_TOP]) turntable();   // spigot up
else if (part == "upright_motor")   translate([0, 0, 0]) rotate([0, -90, 0]) translate([0, 0, 0]) upright_motor();   // inner face on bed
else if (part == "upright_bearing") rotate([0, -90, 0]) upright_bearing();
else if (part == "cradle")     translate([0, 0, -ZF]) cradle();                     // floor on the bed
else if (part == "roll_plate") rotate([180, 0, 0]) translate([0, 0, CAM_H]) roll_plate();   // flat top on the bed
