"""Adapter plate: pan-tilt head (flange 84 x 84, 4x M4 on a 70 mm square) onto a 4040 profile (slot 8).

    python profile_plate.py   -> profile_plate.scad, stl/profile_plate.stl, profile_plate.png

Used for both new cameras from the mount survey (2026-10-29): SIDE stands on top of a 175 mm arm,
DIAG hangs under a 185 mm arm (same plate, upside down). Adjustment before camera_align:
  along the profile: two M6 slots (+-10 mm), plus sliding the whole arm/brackets;
  across the profile: the M4 flange holes are slots (+-5 mm).
Frame (mm): z = 0 is the face against the profile, +z toward the head; the profile runs along y.
"""
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

PLATE = 90.0
T = 10.0
# head flange (pantilt_mount.scad: FLANGE 84, FL_PITCH 70, FL_HOLE 4.5)
FL_PITCH = 70.0
M4_SLOT_W, M4_SLOT_HALF = 4.6, 5.0        # slot width, +- travel across the profile (x)
NUT_AF, NUT_DEPTH = 7.4, 3.6              # M4 hex nut held in a channel on the profile side
# profile side: M6 socket screws into slot-8 T-nuts, heads sunk below the top face (under the flange)
M6_SLOT_W, M6_Y, M6_HALF = 6.6, 25.0, 10.0
CB_W, CB_DEPTH = 11.0, 6.5
KEY_W, KEY_H = 7.8, 1.6                   # small key into the profile slot keeps the plate square to the arm


def slot_xy(cx, cy, half, w, along_x):
    """Stadium as a 2D polygon (for the manifold extrusion)."""
    import manifold3d as m3d
    r = w / 2
    circ = m3d.CrossSection.circle(r, 32)
    a = circ.translate((cx - half, cy) if along_x else (cx, cy - half))
    b = circ.translate((cx + half, cy) if along_x else (cx, cy + half))
    body = m3d.CrossSection.square((2 * half, w) if along_x else (w, 2 * half), center=True).translate((cx, cy))
    return a + b + body


def build():
    import manifold3d as m3d
    plate = m3d.Manifold.cube([PLATE, PLATE, T]).translate([-PLATE / 2, -PLATE / 2, 0])
    key = m3d.Manifold.cube([KEY_W, PLATE, KEY_H]).translate([-KEY_W / 2, -PLATE / 2, -KEY_H])
    solid = plate + key
    cuts = []
    h = FL_PITCH / 2
    for sx in (-1, 1):
        for sy in (-1, 1):
            cx, cy = sx * h, sy * h
            cuts.append(m3d.Manifold.extrude(slot_xy(cx, cy, M4_SLOT_HALF, M4_SLOT_W, True), T + 2).translate([0, 0, -1]))
            cuts.append(m3d.Manifold.extrude(slot_xy(cx, cy, M4_SLOT_HALF, NUT_AF, True), NUT_DEPTH + 1).translate([0, 0, -1]))
    for sy in (-1, 1):
        cy = sy * M6_Y
        cuts.append(m3d.Manifold.extrude(slot_xy(0, cy, M6_HALF, M6_SLOT_W, False), T + KEY_H + 2).translate([0, 0, -KEY_H - 1]))
        cuts.append(m3d.Manifold.extrude(slot_xy(0, cy, M6_HALF, CB_W, False), CB_DEPTH + 1).translate([0, 0, T - CB_DEPTH]))
    for c in cuts:
        solid = solid - c
    return solid


def main():
    import trimesh
    os.makedirs(os.path.join(HERE, "stl"), exist_ok=True)
    solid = build()
    mesh = solid.to_mesh()
    tm = trimesh.Trimesh(vertices=np.asarray(mesh.vert_properties)[:, :3], faces=np.asarray(mesh.tri_verts))
    # print top face down: flat face on the bed, nut channels and the key face up
    tm.apply_transform(trimesh.transformations.rotation_matrix(np.pi, [1, 0, 0]))
    tm.apply_translation(-tm.bounds[0])
    assert tm.is_watertight
    tm.export(os.path.join(HERE, "stl", "profile_plate.stl"))

    # top view drawing
    from PIL import Image, ImageDraw, ImageFont
    s, W = 6, 1000
    img = Image.new("RGB", (W, 700), "white")
    d = ImageDraw.Draw(img)
    f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 15)
    o = np.array([W / 2, 330])

    def P(x, y):
        return tuple(o + np.array([x, -y]) * s)

    d.rectangle([P(-PLATE / 2, PLATE / 2), P(PLATE / 2, -PLATE / 2)], outline="black", width=2, fill=(225, 235, 250))
    d.rectangle([P(-20, PLATE / 2 + 8), P(20, -PLATE / 2 - 8)], outline=(150, 150, 150), width=1)
    d.text(P(22, PLATE / 2 + 14), "4040 profile under the plate (runs along y)", font=f, fill="gray")

    def stadium(cx, cy, half, w, along_x, col):
        if along_x:
            d.rounded_rectangle([P(cx - half - w / 2, cy + w / 2), P(cx + half + w / 2, cy - w / 2)], radius=w / 2 * s,
                                outline=col, width=2)
        else:
            d.rounded_rectangle([P(cx - w / 2, cy + half + w / 2), P(cx + w / 2, cy - half - w / 2)], radius=w / 2 * s,
                                outline=col, width=2)

    for sx in (-1, 1):
        for sy in (-1, 1):
            stadium(sx * h_, sy * h_, M4_SLOT_HALF, M4_SLOT_W, True, (200, 60, 60)) if (h_ := FL_PITCH / 2) else None
    for sy in (-1, 1):
        stadium(0, sy * M6_Y, M6_HALF, CB_W, False, (40, 90, 200))
        stadium(0, sy * M6_Y, M6_HALF, M6_SLOT_W, False, (40, 90, 200))
    d.text((20, 600), f"Plate {PLATE:.0f} x {PLATE:.0f} x {T:.0f} mm, PETG. Red: 4x M4 slots for the head flange (70 mm square, "
                      f"+-{M4_SLOT_HALF:.0f} mm across), nut channels underneath.", font=f, fill="black")
    d.text((20, 622), f"Blue: 2x M6 slots into slot-8 T-nuts (+-{M6_HALF:.0f} mm along the profile), heads sunk "
                      f"{CB_DEPTH} mm below the top. Key under the plate fits the profile slot.", font=f, fill="black")
    d.text((20, 644), "Order: screw the plate to the profile first (M6 x 16), then the head on top (M4 x 20 + nuts).",
           font=f, fill="black")
    img.save(os.path.join(HERE, "profile_plate.png"))
    print("size", np.round(tm.bounds[1], 1), "mm")


if __name__ == "__main__":
    main()
