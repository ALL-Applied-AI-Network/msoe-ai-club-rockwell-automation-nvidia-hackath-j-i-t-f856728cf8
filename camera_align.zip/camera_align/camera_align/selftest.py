"""Self-test without any camera or Isaac Sim: renders the board from a known target pose and from a
deliberately misplaced pose, then checks that align_camera computes exactly the corrections we put in.

  python selftest.py          -> prints expected vs measured, writes selftest_*.png / .json
"""
import json
import os
import sys

import cv2
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from align_camera import ORDER, instruction, pose_errors  # noqa: E402
from board import board_size_m, cam_pose_in_board, detect, estimate_pose, load_board, make_detector  # noqa: E402

board, cfg = load_board()
NOISE = float(os.environ.get("NOISE", 3))
W, H = 1280, 720
K = np.array([[900.0, 0, W / 2], [0, 900.0, H / 2], [0, 0, 1]])
UP = np.array([0.0, -1.0, 0.0])          # vertical board, text upright
E1 = np.array([0.0, 0.0, 1.0])           # horizontal direction from the camera toward the board
L = np.cross(UP, E1)                     # "left" for that camera


def make_cam(C, yaw_left, pitch_up, roll_cw):
    y, p, r = np.radians([yaw_left, pitch_up, roll_cw])
    f = np.cos(p) * (np.cos(y) * E1 + np.sin(y) * L) + np.sin(p) * UP
    r0 = np.cross(f, UP); r0 /= np.linalg.norm(r0)
    y0 = np.cross(f, r0)
    x = np.cos(r) * r0 + np.sin(r) * y0
    yy = np.cos(r) * y0 - np.sin(r) * r0
    T = np.eye(4); T[:3, :3] = np.column_stack([x, yy, f]); T[:3, 3] = C
    return T


def render(T_board_cam, ppm=2000):
    bw, bh = board_size_m(cfg)
    img = board.generateImage((int(bw * ppm), int(bh * ppm)), marginSize=0, borderBits=1)
    Tcb = np.linalg.inv(T_board_cam)
    Hm = K @ np.column_stack([Tcb[:3, 0], Tcb[:3, 1], Tcb[:3, 3]]) @ np.diag([1 / ppm, 1 / ppm, 1])
    out = cv2.warpPerspective(img, Hm, (W, H), borderValue=110)
    noise = np.random.default_rng(0).normal(0, NOISE, out.shape)
    return np.clip(out + noise, 0, 255).astype(np.uint8)


bw, bh = board_size_m(cfg)
C_tgt = np.array([bw / 2 + 0.03, bh / 2 - 0.02, -0.45])   # 45 cm in front of the board
T_tgt = make_cam(C_tgt, yaw_left=4, pitch_up=-3, roll_cw=0)

# Misplace the camera: it must move RIGHT 2 cm, RAISE 1 cm, BACK 3 cm, PAN LEFT 3, TILT DOWN 2, ROLL CW 1.5
expected = {"right_cm": 2.0, "up_cm": 1.0, "fwd_cm": -3.0, "pan_deg": 3.0, "tilt_deg": -2.0, "roll_deg": 1.5}
yaw_c, pitch_c, roll_c = 4 - 3.0, -3 + 2.0, 0 - 1.5
fh = np.cos(np.radians(yaw_c)) * E1 + np.sin(np.radians(yaw_c)) * L
right = np.cross(fh, UP)
C_cur = C_tgt - 0.02 * right - 0.01 * UP + 0.03 * fh
T_cur = make_cam(C_cur, yaw_c, pitch_c, roll_c)

det = make_detector(board)
here = os.path.dirname(os.path.abspath(__file__))
ok_all = True
for name, T, exp in [("target", T_tgt, {k: 0.0 for k in ORDER}), ("misplaced", T_cur, expected)]:
    img = render(T)
    cv2.imwrite(os.path.join(here, f"selftest_{name}.png"), img)
    ch_c, ch_i, _, _ = detect(det, img)
    res = estimate_pose(board, ch_c, ch_i, K, np.zeros(5))
    assert res is not None, f"board not detected in {name} render"
    T_est = cam_pose_in_board(res[0], res[1])
    e = pose_errors(T_est, T_tgt, UP)
    print(f"--- {name}: {len(ch_i)} corners, reprojection {res[2]:.3f}px, position error "
          f"{1000*np.linalg.norm(T_est[:3,3]-T[:3,3]):.2f} mm")
    for k in ORDER:
        tol = 0.15
        good = abs(e[k] - exp[k]) < tol
        ok_all &= good
        print(f"  {k:9s} expected {exp[k]:+6.2f}  measured {e[k]:+6.2f}  {'ok' if good else 'MISMATCH'}"
              f"   -> {instruction(k, e[k])}")

# files so the CLI can be tried too:  python align_camera.py --image selftest_misplaced.png \
#   --calib selftest_calib.json --target selftest_target.json
json.dump({"K": K.tolist(), "dist": [0, 0, 0, 0, 0], "image_size": [W, H]},
          open(os.path.join(here, "selftest_calib.json"), "w"), indent=2)
json.dump({"source": "selftest", "T_board_cam": T_tgt.tolist(), "up_in_board": UP.tolist(),
           "intrinsics": {"K": K.tolist(), "image_size": [W, H]}, "reference_image": "selftest_target.png"},
          open(os.path.join(here, "selftest_target.json"), "w"), indent=2)
print("PASS" if ok_all else "FAIL")
sys.exit(0 if ok_all else 1)
